
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext.tsx';
import { Skeleton } from './common/Skeleton.tsx';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isAuthLoading } = useAppContext();
  const location = useLocation();

  if (isAuthLoading) {
    return (
        <div className="space-y-8">
            <Skeleton className="h-16 w-3/4 mb-8" />
            <Skeleton className="h-64 w-full" />
        </div>
    );
  }

  if (!user || user.isAnonymous) {
    // Redirect them to the login page if they are not logged in.
    // Save the location they were trying to go to so we can send them there after login.
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;