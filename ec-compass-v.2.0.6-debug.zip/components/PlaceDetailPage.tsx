
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Camera } from 'lucide-react';
import { useAppContext } from '../context/AppContext.tsx';
import { Skeleton } from './common/Skeleton.tsx';
import { Badge } from './common/Badge.tsx';
import VibeIcon from './common/Icons.tsx';
import EnglishCornerCard from './EnglishCornerCard.tsx';
import ImageLightbox from './common/ImageLightbox.tsx';
import { Image, PlaceInsights } from '../types.ts';
import { generatePlaceInsights } from '../services/geminiService.ts';
import { PlaceInsightsIndicators } from './common/PlaceInsightsIndicators.tsx';
import SaveButton from './common/BucketListButton.tsx';
import WhoIsGoing from './WhoIsGoing.tsx';
import PlanEventWizard from './PlanEventWizard.tsx';
import ActiveEvents from './ActiveEvents.tsx';
import FunFactsCard from './FunFactsCard.tsx';


const InfoBlock = ({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) => (
    <div className="flex items-start gap-3">
        <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center mt-1">{icon}</div>
        <div>
            <p className="text-sm font-medium text-slate-500">{label}</p>
            <p className="text-md font-semibold text-[#1C3A3A]">{value}</p>
        </div>
    </div>
);

const variants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1
  },
  exit: (direction: number) => ({
    zIndex: 0,
    x: direction < 0 ? 300 : -300,
    opacity: 0
  })
};

export default function PlaceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { getPlaceById, isLoading, user } = useAppContext();
  const [[page, direction], setPage] = useState([0, 0]);
  const [lightboxImage, setLightboxImage] = useState<Image | null>(null);
  const [insights, setInsights] = useState<PlaceInsights | null>(null);
  const [isInsightsLoading, setIsInsightsLoading] = useState(true);
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const navigate = useNavigate();

  const place = getPlaceById(id!);

  useEffect(() => {
    if (place) {
        const fetchInsights = async () => {
            setIsInsightsLoading(true);
            const cacheKey = `place-insights-${place.id}`;

            // Check session storage first
            try {
                const cachedInsights = sessionStorage.getItem(cacheKey);
                if (cachedInsights) {
                    setInsights(JSON.parse(cachedInsights));
                    setIsInsightsLoading(false);
                    return; // Found in cache, no need to fetch
                }
            } catch (e) {
                console.error("Failed to read insights from cache", e);
            }

            // If not in cache, fetch from API
            const result = await generatePlaceInsights(place.englishCorner);
            setInsights(result);
            
            // Store result in session storage for this session
            if (result) {
                try {
                    sessionStorage.setItem(cacheKey, JSON.stringify(result));
                } catch(e) {
                    console.error("Failed to write insights to cache", e);
                }
            }
            setIsInsightsLoading(false);
        };
        fetchInsights();
    }
  }, [place]);

  const handleEventCreated = (eventId: string) => {
    setIsWizardOpen(false);
    // Potentially show a success toast or navigate to an event page
    // For now, just close the wizard. The ActiveEvents component will update.
  }

  if (isLoading) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-80 w-full rounded-2xl" />
        <Skeleton className="h-12 w-3/4" />
        <Skeleton className="h-8 w-1/2" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
            <Skeleton className="h-24 w-full"/>
            <Skeleton className="h-24 w-full"/>
            <Skeleton className="h-24 w-full"/>
            <Skeleton className="h-24 w-full"/>
        </div>
        <Skeleton className="h-56 w-full" />
      </div>
    );
  }

  if (!place) {
    return (
      <div className="text-center py-20">
        <h2 className="font-lora text-4xl font-bold text-[#1C3A3A]">Place not found</h2>
        <p className="text-slate-500 mt-2">The place you're looking for doesn't exist or has been moved.</p>
        <Link to="/" className="mt-8 inline-block bg-[#1C3A3A] text-white font-bold py-3 px-8 rounded-full hover:bg-opacity-90 transition-colors">
            Back to Home
        </Link>
      </div>
    );
  }
  
  const images = place.images || [];
  const imageIndex = page;

  const paginate = (newDirection: number) => {
      if (images.length <= 1) return;
      const newIndex = (imageIndex + newDirection + images.length) % images.length;
      setPage([newIndex, newDirection]);
  };
  
  const currentImage = images[imageIndex];
  const allTags = [...(place.tags.vibeTags || []), ...(place.tags.bestFor || [])];

  return (
    <div className="space-y-10 lg:space-y-12">
        <AnimatePresence>
            {isWizardOpen && (
                <PlanEventWizard 
                    placeId={place.id}
                    placeName={place.name}
                    onClose={() => setIsWizardOpen(false)} 
                    onEventCreated={handleEventCreated}
                />
            )}
        </AnimatePresence>
        <div className="relative group">
            <div 
                className="relative w-full h-80 overflow-hidden rounded-3xl shadow-2xl shadow-slate-400/20 cursor-zoom-in"
                onClick={() => setLightboxImage(currentImage)}
                role="button"
                aria-label="View image in full screen"
            >
                <AnimatePresence initial={false} custom={direction}>
                    <motion.img
                        key={page}
                        src={currentImage?.url}
                        alt={`${place.name} image ${imageIndex + 1}`}
                        custom={direction}
                        variants={variants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{
                            x: { type: "spring", stiffness: 300, damping: 30 },
                            opacity: { duration: 0.2 }
                        }}
                        className="absolute w-full h-full object-cover"
                    />
                </AnimatePresence>
                {currentImage?.author && currentImage.author !== 'N/A' && currentImage.author !== 'Placeholder' && (
                    <div className="absolute bottom-4 right-4 z-10 bg-black/40 text-white/90 text-[11px] px-2 py-1 rounded-md backdrop-blur-sm flex items-center gap-1.5 pointer-events-none">
                        <Camera className="w-3 h-3" />
                        <span>Photo by {currentImage.author} on {currentImage.source}</span>
                    </div>
                )}
            </div>
             <div className="absolute top-4 right-4 z-20">
                <SaveButton placeId={place.id} />
             </div>
             <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent rounded-3xl pointer-events-none"></div>
             <div className="absolute bottom-8 left-8 text-white max-w-[calc(100%-7rem)] z-10 pointer-events-none">
                <h1 className="font-lora text-5xl font-bold tracking-tight drop-shadow-lg">{place.name}</h1>
                <div className="flex flex-wrap gap-2 mt-3">
                    {allTags.map(tag => <Badge key={tag} className="bg-white/10 text-white backdrop-blur-lg border border-white/20">{tag.startsWith('#') ? tag : `#${tag}`}</Badge>)}
                </div>
            </div>
            {images.length > 1 && (
                <>
                    <button onClick={(e) => { e.stopPropagation(); paginate(-1); }} aria-label="Previous Image" className="absolute top-1/2 left-3 z-20 -translate-y-1/2 bg-white/50 p-2.5 rounded-full backdrop-blur-sm text-slate-800 hover:bg-white/80 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100">
                        <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); paginate(1); }} aria-label="Next Image" className="absolute top-1/2 right-3 z-20 -translate-y-1/2 bg-white/50 p-2.5 rounded-full backdrop-blur-sm text-slate-800 hover:bg-white/80 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100">
                        <ChevronRight className="w-6 h-6" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
                        {images.map((_, i) => (
                            <div key={i} onClick={(e) => { e.stopPropagation(); setPage([i, i > imageIndex ? 1 : -1]); }} className={`w-2.5 h-2.5 cursor-pointer rounded-full transition-all duration-300 ${i === imageIndex ? 'bg-white scale-110' : 'bg-white/50 hover:bg-white/75'}`} />
                        ))}
                    </div>
                </>
             )}
        </div>
        
        <p className="text-lg text-slate-600 leading-relaxed text-center max-w-3xl mx-auto">{place.details.description}</p>

        <PlaceInsightsIndicators insights={insights} isLoading={isInsightsLoading} />
        
        {user && !user.isAnonymous && (
          <div className="space-y-6">
            <WhoIsGoing placeId={place.id} onPlanEvent={() => setIsWizardOpen(true)} />
            <ActiveEvents placeId={place.id} />
          </div>
        )}

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-8">
                <InfoBlock icon={<VibeIcon type="MapPin" className="w-6 h-6 text-slate-400"/>} label="Address" value={place.location.address} />
                <InfoBlock icon={<VibeIcon type="Clock" className="w-6 h-6 text-slate-400"/>} label="Walk from EC" value={place.location.walkFromEC} />
                <InfoBlock icon={<VibeIcon type="DollarSign" className="w-6 h-6 text-slate-400"/>} label="Price" value={place.pricing.range} />
                <InfoBlock icon={<VibeIcon type="Star" className="w-6 h-6 text-slate-400"/>} label="Best Time" value={place.details.bestTime} />
            </div>
        </div>

        <div className="bg-[#FF712F]/10 border-l-4 border-[#FF712F] p-6 rounded-r-xl">
            <h3 className="font-lora text-2xl font-bold text-[#c75825] flex items-center gap-3">
                <VibeIcon type="Sparkles" className="w-6 h-6" />
                Insider Tip
            </h3>
            <p className="mt-2 text-[#99451d] leading-relaxed text-md">{place.details.whySpecial} {place.details.localTip}</p>
        </div>
        
        <FunFactsCard facts={place.details.funFacts} />

        <EnglishCornerCard englishCorner={place.englishCorner} />

        <AnimatePresence>
            {lightboxImage && (
                <ImageLightbox image={lightboxImage} onClose={() => setLightboxImage(null)} />
            )}
        </AnimatePresence>
    </div>
  );
}