
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Place } from '../types.ts';
import VibeIcon from './common/Icons.tsx';

interface EnglishCornerCardProps {
  englishCorner: Place['englishCorner'];
}

const cardVariants = {
    initial: { rotateY: 0 },
    flipped: { rotateY: 180 },
};

const contentVariants = {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
};

export default function EnglishCornerCard({ englishCorner }: EnglishCornerCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  const cardContent = (
    <div className="p-6 h-full overflow-y-auto">
        <h3 className="font-lora font-bold text-2xl text-[#1C3A3A] mb-4 text-center">English Corner</h3>
        
        <div className="space-y-5 text-sm">
            <div>
                <h4 className="font-semibold text-slate-700 mb-2">Conversation Starters</h4>
                <ul className="list-disc list-inside space-y-2 text-slate-600">
                    {englishCorner.conversationStarters.map((starter, i) => <li key={i}>{starter}</li>)}
                </ul>
            </div>
            <div>
                <h4 className="font-semibold text-slate-700 mb-2">Useful Phrases</h4>
                <ul className="list-disc list-inside space-y-2 text-slate-600">
                    {englishCorner.usefulPhrases.map((phrase, i) => <li key={i}>{phrase}</li>)}
                </ul>
            </div>
            <div>
                <h4 className="font-semibold text-slate-700 mb-2">Cultural Context</h4>
                <p className="text-slate-600 leading-relaxed">{englishCorner.culturalContext}</p>
            </div>
        </div>
    </div>
  );

  return (
    <div className="perspective-1000">
      <motion.div
        className="relative w-full min-h-[350px] cursor-pointer"
        onClick={() => setIsFlipped(!isFlipped)}
        style={{ transformStyle: 'preserve-3d' }}
        animate={isFlipped ? 'flipped' : 'initial'}
        variants={cardVariants}
        transition={{ duration: 0.7, ease: 'easeInOut' }}
      >
        {/* Front of card */}
        <div className="absolute w-full h-full backface-hidden bg-gradient-to-br from-[#1C3A3A] to-[#2c5757] rounded-2xl flex flex-col items-center justify-center p-6 text-white text-center shadow-2xl shadow-[#1C3A3A]/20">
            <VibeIcon type="BookOpen" className="w-16 h-16 mb-4 text-[#FF712F]" />
            <h3 className="font-lora text-3xl font-bold">English Corner</h3>
            <p className="mt-2 text-slate-300 max-w-xs">Tap to learn useful phrases & cultural tips for this place!</p>
        </div>

        {/* Back of card */}
        <div className="absolute w-full h-full backface-hidden bg-white border border-slate-200/80 rounded-2xl" style={{ transform: 'rotateY(180deg)' }}>
            <AnimatePresence>
                {isFlipped && (
                    <motion.div
                        variants={contentVariants}
                        initial="initial"
                        animate="animate"
                        transition={{ delay: 0.3, duration: 0.3 }}
                        className="h-full"
                    >
                        {cardContent}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}