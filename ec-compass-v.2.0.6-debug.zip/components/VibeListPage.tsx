
import React, { useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { useAppContext } from '../context/AppContext.tsx';
import { Skeleton } from './common/Skeleton.tsx';
import PlaceCard from './PlaceCard.tsx';
import { VIBES } from '../constants.ts';
import VibeIcon from './common/Icons.tsx';

export default function VibeListPage() {
  const { vibe } = useParams<{ vibe: string }>();
  const { places, isLoading } = useAppContext();

  const vibeDetails = VIBES.find(v => v.id === vibe);

  const filteredPlaces = useMemo(() => {
    if (!vibe || !vibeDetails) return [];

    return places.filter(place => {
      // Combine all searchable text for the place
      const allTags = [...(place.tags.vibeTags || []), ...(place.tags.bestFor || [])];
      const placeText = (place.category + ' ' + allTags.join(' ')).toLowerCase();
      
      // Check if any vibe keyword matches the place's text
      return vibeDetails.keywords.some(keyword => placeText.includes(keyword));
    });
  }, [places, vibe, vibeDetails]);

  if (isLoading) {
    return (
      <div>
        <Skeleton className="h-16 w-3/4 mb-8" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <Skeleton className="h-80 rounded-2xl" />
          <Skeleton className="h-80 rounded-2xl" />
          <Skeleton className="h-80 rounded-2xl" />
        </div>
      </div>
    );
  }

  const title = vibeDetails ? vibeDetails.name : 'Explore Vibe';
  const icon = vibeDetails ? vibeDetails.icon : 'Sparkles';

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-5 border-b border-slate-200/80 pb-6">
        <div className="w-20 h-20 bg-[#FF712F]/20 rounded-2xl flex items-center justify-center">
            <VibeIcon type={icon} className="w-10 h-10 text-[#FF712F]" />
        </div>
        <div>
            <p className="text-sm font-semibold text-[#FF712F]">Vibe</p>
            <h1 className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A] tracking-tight">{title}</h1>
        </div>
      </div>
     
      {filteredPlaces.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlaces.map(place => (
            <PlaceCard key={place.id} place={place} />
          ))}
        </div>
      ) : (
        <p className="text-center py-20 text-slate-500">No places found matching the "{title}" vibe.</p>
      )}
    </div>
  );
}