
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../context/AppContext.tsx';
import { generateWalkTour } from '../services/geminiService.ts';
import { Place, WalkTour, WalkTourStep } from '../types.ts';
import { VIBES, BUDGET_OPTIONS } from '../constants.ts';
import { Skeleton } from './common/Skeleton.tsx';
import VibeIcon from './common/Icons.tsx';
import { useNavigate } from 'react-router-dom';
import { X, Bot } from 'lucide-react';

// --- Google Map Component ---

const mapStyles = [
  { elementType: 'geometry', stylers: [{ color: '#f5f5f5' }] },
  { elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#616161' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#f5f5f5' }] },
  { featureType: 'administrative.land_parcel', stylers: [{ visibility: 'off' }] },
  { featureType: 'administrative.neighborhood', stylers: [{ visibility: 'off' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#eeeeee' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#757575' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#e5e5e5' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#9e9e9e' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#ffffff' }] },
  { featureType: 'road.arterial', elementType: 'labels.text.fill', stylers: [{ color: '#757575' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#dadada' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#616161' }] },
  { featureType: 'road.local', elementType: 'labels.text.fill', stylers: [{ color: '#9e9e9e' }] },
  { featureType: 'transit.line', elementType: 'geometry', stylers: [{ color: '#e5e5e5' }] },
  { featureType: 'transit.station', elementType: 'geometry', stylers: [{ color: '#eeeeee' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#c9c9c9' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#9e9e9e' }] },
];


const GoogleMapComponent = ({ places, onPinClick, selectedPlace }: { places: Place[], onPinClick: (place: Place) => void, selectedPlace: Place | null }) => {
    const mapRef = useRef<HTMLDivElement>(null);
    const [map, setMap] = useState<google.maps.Map | null>(null);
    const markersRef = useRef<{ [key: string]: google.maps.Marker }>({});

    useEffect(() => {
        if (mapRef.current && !map) {
            const newMap = new window.google.maps.Map(mapRef.current, {
                center: { lat: 37.7749, lng: -122.4194 },
                zoom: 12.5,
                styles: mapStyles,
                disableDefaultUI: true,
                zoomControl: true,
            });
            setMap(newMap);
        }
    }, [mapRef, map]);

    useEffect(() => {
        if (map) {
            const currentMarkers = markersRef.current;
            const placeIds = new Set(places.map(p => p.id));

            // Remove markers that are no longer in the filtered list
            Object.keys(currentMarkers).forEach(id => {
                if (!placeIds.has(id)) {
                    currentMarkers[id].setMap(null);
                    delete currentMarkers[id];
                }
            });

            // Add new markers
            places.forEach(place => {
                if (!currentMarkers[place.id]) {
                    const marker = new window.google.maps.Marker({
                        position: place.location.coordinates,
                        map,
                        title: place.name,
                        icon: {
                            path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
                            fillColor: '#D32F2F',
                            fillOpacity: 1,
                            strokeWeight: 0,
                            rotation: 0,
                            scale: 1.5,
                            anchor: new window.google.maps.Point(12, 24),
                        },
                        animation: window.google.maps.Animation.DROP,
                    });

                    marker.addListener('click', () => {
                        onPinClick(place);
                    });
                    currentMarkers[place.id] = marker;
                }
            });
        }
    }, [map, places, onPinClick]);

     useEffect(() => {
        if (map && markersRef.current) {
             Object.values(markersRef.current).forEach(marker => {
                 const isSelected = marker.getTitle() === selectedPlace?.name;
                 marker.setIcon({
                    path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
                    fillColor: isSelected ? '#FF712F' : '#D32F2F',
                    fillOpacity: 1,
                    strokeColor: '#ffffff',
                    strokeWeight: isSelected ? 3 : 0,
                    scale: isSelected ? 2.2 : 1.5,
                    anchor: new window.google.maps.Point(12, 24),
                 });
                 marker.setZIndex(isSelected ? 100 : 1);
            });

            if (selectedPlace) {
                map.panTo(selectedPlace.location.coordinates);
                if(map.getZoom()! < 14) {
                    map.setZoom(14);
                }
            }
        }
    }, [map, selectedPlace]);

    return <div ref={mapRef} style={{ width: '100%', height: '100%' }} />;
};


const TourStepCard = ({ step, index }: { step: WalkTourStep, index: number }) => {
    const { getPlaceById } = useAppContext();
    const navigate = useNavigate();
    const place = getPlaceById(step.placeId);

    if (!place) return null;

    return (
        <div className="flex gap-4 items-start">
            <div className="w-8 h-8 rounded-full bg-[#FF712F] text-white text-sm font-bold flex items-center justify-center flex-shrink-0 mt-3 shadow-inner shadow-black/10">{index + 1}</div>
            <div className="flex-1 bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                 <p className="text-slate-700 font-medium mb-2">{step.instruction}</p>
                 <div 
                    className="flex items-center gap-3 cursor-pointer group"
                    onClick={() => navigate(`/place/${place.id}`)}
                 >
                    <img src={place.imageUrl} alt={place.name} className="w-12 h-12 object-cover rounded-lg"/>
                    <div>
                        <p className="font-semibold text-slate-800 group-hover:underline">{place.name}</p>
                        <p className="text-xs text-slate-500">{place.location.neighborhood}</p>
                    </div>
                 </div>
            </div>
        </div>
    )
}

const WalkTourGenerator = () => {
    const { places } = useAppContext();
    const [tour, setTour] = useState<WalkTour | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [selectedNeighborhood, setSelectedNeighborhood] = useState('');
    
    const neighborhoods = useMemo(() => [...new Set(places.map(p => p.location.neighborhood))].sort(), [places]);

    const handleGenerateTour = async () => {
        if (!selectedNeighborhood) {
            setError('Please select a neighborhood first.');
            return;
        }
        setIsLoading(true);
        setError('');
        setTour(null);
        const result = await generateWalkTour(places, selectedNeighborhood, '90 minutes');
        if(result) {
            setTour(result);
        } else {
            setError('Could not generate a tour for this area. Please try another.');
        }
        setIsLoading(false);
    };

    return (
        <div className="bg-white p-6 rounded-2xl shadow-xl shadow-slate-200/40 border border-slate-200/80">
            <h3 className="font-lora font-bold text-2xl text-[#1C3A3A] flex items-center gap-3"><Bot className="w-7 h-7 text-[#FF712F]"/>AI Walk Tour Generator</h3>
            <p className="text-sm text-slate-500 mb-5">Let Compass create a custom walking tour for you.</p>
            <div className="grid sm:grid-cols-[1fr,auto] gap-3">
                <select 
                    value={selectedNeighborhood}
                    onChange={(e) => setSelectedNeighborhood(e.target.value)}
                    className="w-full p-3.5 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] focus:border-[#1C3A3A] transition"
                >
                    <option value="">Select a Neighborhood...</option>
                    {neighborhoods.map((n: string) => <option key={n} value={n}>{n}</option>)}
                </select>
                <button onClick={handleGenerateTour} disabled={isLoading || !selectedNeighborhood} className="w-full sm:w-auto bg-[#1C3A3A] text-white font-semibold px-6 py-3.5 rounded-xl hover:bg-opacity-90 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors">
                    {isLoading ? 'Creating...' : 'Create Tour'}
                </button>
            </div>
            <AnimatePresence>
                {error && <motion.p initial={{opacity: 0}} animate={{opacity: 1}} exit={{opacity: 0}} className="text-red-600 text-sm mt-3">{error}</motion.p>}
                {tour && (
                    <motion.div initial={{opacity: 0, y:10}} animate={{opacity: 1, y: 0}} className="mt-5 border-t border-slate-200 pt-5">
                        <h4 className="font-lora font-bold text-xl text-slate-800">{tour.title}</h4>
                        <div className="mt-4 space-y-4">
                            {tour.steps.map((step, i) => (
                                <TourStepCard key={step.placeId} step={step} index={i} />
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

export default function MapPage() {
  const { places, isLoading } = useAppContext();
  const [activeVibeFilters, setActiveVibeFilters] = useState<string[]>([]);
  const [activeBudgetFilters, setActiveBudgetFilters] = useState<string[]>([]);
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [isApiLoaded, setIsApiLoaded] = useState(window.googleMapsApiLoaded || false);
  const navigate = useNavigate();

  useEffect(() => {
    if (window.googleMapsApiLoaded) {
      setIsApiLoaded(true);
      return;
    }
    const handleApiLoad = () => setIsApiLoaded(true);
    document.addEventListener('googleMapsApiLoaded', handleApiLoad);
    return () => {
      document.removeEventListener('googleMapsApiLoaded', handleApiLoad);
    };
  }, []);

  const filteredPlaces = useMemo(() => {
    return places.filter(place => {
        const matchesVibe = activeVibeFilters.length === 0 || activeVibeFilters.some(vibeId => {
            const vibeDetails = VIBES.find(v => v.id === vibeId);
            if (!vibeDetails) return false;
            const allTags = [...(place.tags.vibeTags || []), ...(place.tags.bestFor || [])];
            const placeText = (place.category + ' ' + allTags.join(' ')).toLowerCase();
            return vibeDetails.keywords.some(keyword => placeText.includes(keyword));
        });
        
        const matchesBudget = activeBudgetFilters.length === 0 || activeBudgetFilters.some(budgetId => {
            const budgetDetails = BUDGET_OPTIONS.find(b => b.id === budgetId);
            if (!budgetDetails) return false;
            return budgetDetails.range.includes(place.pricing.range);
        });

        return matchesVibe && matchesBudget;
    });
  }, [places, activeVibeFilters, activeBudgetFilters]);

  const toggleVibeFilter = (vibeId: string) => {
    setActiveVibeFilters(prev =>
      prev.includes(vibeId)
        ? prev.filter(id => id !== vibeId)
        : [...prev, vibeId]
    );
    setSelectedPlace(null);
  };

  const toggleBudgetFilter = (budgetId: string) => {
    setActiveBudgetFilters(prev =>
      prev.includes(budgetId)
        ? prev.filter(id => id !== budgetId)
        : [...prev, budgetId]
    );
    setSelectedPlace(null);
  };


  if (isLoading || !isApiLoaded) {
    return (
        <div className="space-y-8">
            <Skeleton className="h-16 w-3/4 mb-8" />
            <Skeleton className="h-[600px] w-full rounded-3xl" />
        </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-lora text-5xl lg:text-6xl font-bold text-[#1C3A3A] tracking-tight">The Smart Map</h1>
        <p className="text-lg text-slate-500 mt-2">Filter places by vibe and budget to tailor your discovery.</p>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-500">Filter by Vibe</h3>
        <div className="flex flex-wrap gap-2.5">
            {VIBES.map(vibe => (
              <button
                key={vibe.id}
                onClick={() => toggleVibeFilter(vibe.id)}
                className={`px-4 py-2 text-sm font-semibold rounded-full transition-all duration-300 flex items-center gap-2 border-2 ${
                  activeVibeFilters.includes(vibe.id)
                    ? 'bg-[#1C3A3A] text-white border-transparent shadow-md'
                    : 'bg-white text-slate-600 border-slate-200/80 hover:border-[#1C3A3A]/50 hover:text-[#1C3A3A]'
                }`}
              >
                <VibeIcon type={vibe.icon} className="w-4 h-4" />
                {vibe.name}
              </button>
            ))}
        </div>
      </div>
      
       <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-500">Filter by Budget</h3>
        <div className="flex flex-wrap gap-2.5">
            {BUDGET_OPTIONS.map(budget => (
              <button
                key={budget.id}
                onClick={() => toggleBudgetFilter(budget.id)}
                className={`px-4 py-2 text-sm font-semibold rounded-full transition-all duration-300 flex items-center gap-2 border-2 ${
                  activeBudgetFilters.includes(budget.id)
                    ? 'bg-[#1C3A3A] text-white border-transparent shadow-md'
                    : 'bg-white text-slate-600 border-slate-200/80 hover:border-[#1C3A3A]/50 hover:text-[#1C3A3A]'
                }`}
              >
                <VibeIcon type={budget.icon} className="w-4 h-4" />
                {budget.label}
              </button>
            ))}
        </div>
      </div>


      <div className="relative w-full h-[500px] lg:h-[600px] bg-slate-200 rounded-3xl overflow-hidden shadow-inner border border-slate-200/80">
        <GoogleMapComponent places={filteredPlaces} onPinClick={setSelectedPlace} selectedPlace={selectedPlace}/>
      </div>
        
      <AnimatePresence>
        {selectedPlace && (
            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 50, opacity: 0 }}
                transition={{ type: "spring", stiffness: 200, damping: 25 }}
                className="fixed bottom-0 left-0 right-0 p-3 lg:absolute lg:bottom-5 lg:left-5 lg:right-auto lg:w-96 z-20"
            >
                <div className="bg-white/80 backdrop-blur-xl p-3 rounded-2xl shadow-2xl shadow-black/10 flex items-center gap-4 border border-slate-200/80">
                    <img src={selectedPlace.imageUrl} alt={selectedPlace.name} className="w-28 h-28 object-cover rounded-xl"/>
                    <div className="flex-1">
                        <h4 className="font-lora font-bold text-lg text-[#1C3A3A]">{selectedPlace.name}</h4>
                        <p className="text-sm text-slate-500">{selectedPlace.location.neighborhood}</p>
                        <button onClick={() => navigate(`/place/${selectedPlace.id}`)} className="text-sm font-bold text-[#1C3A3A] hover:underline mt-2.5">
                            View Details &rarr;
                        </button>
                    </div>
                     <button onClick={() => setSelectedPlace(null)} className="absolute top-2 right-2 text-slate-500 hover:text-slate-800 self-start p-1.5 rounded-full bg-white/50 hover:bg-white transition-colors">
                        <X className="w-4 h-4"/>
                     </button>
                </div>
            </motion.div>
        )}
      </AnimatePresence>
      
      <WalkTourGenerator />

    </div>
  );
}