
import React from 'react';
import { motion } from 'framer-motion';
import { PlaceInsights } from '../../types.ts';
import VibeIcon from './Icons.tsx';
import { Skeleton } from './Skeleton.tsx';

interface IndicatorProps {
    icon: React.ReactNode;
    label: string;
    children: React.ReactNode;
    className?: string;
}

const Indicator: React.FC<IndicatorProps> = ({ icon, label, children, className }) => (
    <motion.div 
        className={`flex flex-col items-center justify-center text-center p-4 bg-slate-50/70 rounded-2xl border border-slate-200/50 ${className}`}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
    >
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-500">
            {icon}
            <span>{label}</span>
        </div>
        <div className="mt-2.5 font-bold text-lg text-[#1C3A3A]">
            {children}
        </div>
    </motion.div>
);

const EnglishComfortIndicator = ({ score }: { score: number }) => {
    const comfort = {
        level: 'Unknown',
        color: 'text-slate-500',
        iconColor: 'bg-slate-300'
    };

    if (score <= 2) {
        comfort.level = 'Challenging';
        comfort.color = 'text-red-600';
        comfort.iconColor = 'bg-red-500';
    } else if (score === 3) {
        comfort.level = 'Moderate';
        comfort.color = 'text-amber-600';
        comfort.iconColor = 'bg-amber-500';
    } else if (score >= 4) {
        comfort.level = 'Comfortable';
        comfort.color = 'text-teal-600';
        comfort.iconColor = 'bg-teal-500';
    }

    return (
        <div className="flex flex-col items-center">
            <div className="flex gap-1.5 mb-1.5">
                {[...Array(5)].map((_, i) => (
                    <div key={i} className={`w-3 h-3 rounded-full ${i < score ? comfort.iconColor : 'bg-slate-200'}`} />
                ))}
            </div>
            <span className={`text-sm font-medium ${comfort.color}`}>{comfort.level}</span>
        </div>
    );
};

const SocialLevelIndicator = ({ level }: { level: PlaceInsights['socialLevel'] }) => {
    const levels = {
        'Quiet': { icon: <VibeIcon type="MicOff" className="w-6 h-6" />, text: 'Quiet' },
        'Moderate': { icon: <VibeIcon type="MessageCircle" className="w-6 h-6" />, text: 'Moderate' },
        'Lively': { icon: <VibeIcon type="Users" className="w-6 h-6" />, text: 'Lively' },
        'Very Social': { icon: <VibeIcon type="PartyPopper" className="w-6 h-6" />, text: 'Very Social' }
    };
    const current = levels[level] || levels['Moderate'];

    return (
        <div className="flex items-center gap-2">
            {current.icon}
            <span>{current.text}</span>
        </div>
    );
};

const BestForIndicator = ({ type }: { type: PlaceInsights['bestFor'] }) => {
    const types = {
        'Solo': { icon: <VibeIcon type="User" className="w-6 h-6" />, text: 'Solo Friendly' },
        'Group': { icon: <VibeIcon type="Users" className="w-6 h-6" />, text: 'Group Activity' },
        'Mixed': { icon: <VibeIcon type="UserPlus" className="w-6 h-6" />, text: 'Solo or Group' }
    };
    const current = types[type] || types['Mixed'];
    
    return (
        <div className="flex items-center gap-2">
            {current.icon}
            <span>{current.text}</span>
        </div>
    );
};


const LoadingSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
    </div>
);

interface PlaceInsightsIndicatorsProps {
    insights: PlaceInsights | null;
    isLoading: boolean;
}

export const PlaceInsightsIndicators: React.FC<PlaceInsightsIndicatorsProps> = ({ insights, isLoading }) => {
    if (isLoading) {
        return <LoadingSkeleton />;
    }

    if (!insights) {
        return null; // Or a message indicating insights couldn't be loaded
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Indicator icon={<VibeIcon type="BookOpen" className="w-4 h-4" />} label="English Comfort">
                <EnglishComfortIndicator score={insights.englishComfort} />
            </Indicator>
            <Indicator icon={<VibeIcon type="Sparkles" className="w-4 h-4" />} label="Social Level">
                <SocialLevelIndicator level={insights.socialLevel} />
            </Indicator>
            <Indicator icon={<VibeIcon type="Heart" className="w-4 h-4" />} label="Best For">
                <BestForIndicator type={insights.bestFor} />
            </Indicator>
        </div>
    );
};