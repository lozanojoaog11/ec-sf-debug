
import React from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { useAppContext } from '../../context/AppContext.tsx';
import VibeIcon from './Icons.tsx';
import { Star } from 'lucide-react';

interface SaveButtonProps {
    placeId: string;
    className?: string;
}

const SaveButton: React.FC<SaveButtonProps> = ({ placeId, className }) => {
    const { user, bucketList, addToBucketList, removeFromBucketList } = useAppContext();

    if (!user || user.isAnonymous) {
        return null;
    }

    const isSaved = !!bucketList[placeId] && bucketList[placeId].status === 'want-to-go';

    const handleClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        e.preventDefault();
        if (isSaved) {
            removeFromBucketList(placeId);
        } else {
            addToBucketList(placeId);
        }
    };
    
    const iconVariants: Variants = {
        initial: { scale: 0 },
        animate: { scale: 1, transition: { type: 'spring', stiffness: 400, damping: 20 } },
        exit: { scale: 0 }
    }

    return (
        <button
            onClick={handleClick}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 backdrop-blur-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#FF712F] ${
                isSaved
                ? 'bg-[#FF712F]/80 text-white shadow-lg shadow-[#FF712F]/30 hover:bg-[#FF712F]'
                : 'bg-white/50 text-[#1C3A3A] hover:bg-white/80'
            } ${className}`}
            aria-label={isSaved ? 'Remove from your list' : 'Save to your list'}
        >
            <AnimatePresence mode="popLayout" initial={false}>
                <motion.div
                    key={isSaved ? 'saved' : 'unsaved'}
                    variants={iconVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                >
                    <Star 
                        className="w-5 h-5"
                        style={{ fill: isSaved ? 'currentColor' : 'transparent' }}
                    />
                </motion.div>
            </AnimatePresence>
        </button>
    );
};

export default SaveButton;