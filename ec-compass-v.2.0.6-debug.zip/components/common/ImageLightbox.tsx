
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { Image } from '../../types.ts';

interface ImageLightboxProps {
  image: Image | null;
  onClose: () => void;
}

const ImageLightbox: React.FC<ImageLightboxProps> = ({ image, onClose }) => {
  const [scale, setScale] = useState(1);
  const constraintsRef = useRef(null);

  if (!image) return null;

  const handleZoom = (direction: 'in' | 'out' | 'reset') => {
    if (direction === 'reset') {
        setScale(1);
    } else {
        const newScale = direction === 'in' ? scale * 1.5 : scale / 1.5;
        const clampedScale = Math.max(1, Math.min(newScale, 8)); // Clamp scale
        setScale(clampedScale);
    }
  };

  return (
    <AnimatePresence>
        {image && (
            <motion.div
                ref={constraintsRef}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onClose}
                className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 overflow-hidden"
                aria-modal="true"
                role="dialog"
            >
                {/* Image Wrapper for zooming and panning */}
                <motion.div
                    className="relative w-auto h-auto"
                    onClick={(e) => e.stopPropagation()}
                    animate={{ scale }}
                    transition={{ duration: 0.3 }}
                    drag={scale > 1}
                    dragConstraints={constraintsRef}
                    dragElastic={0.1}
                    whileTap={{ cursor: "grabbing" }}
                >
                    <img
                        src={image.url}
                        alt={`Full view of ${image.author}'s photo`}
                        className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg shadow-2xl select-none"
                        style={{ cursor: scale > 1 ? 'grab' : 'auto' }}
                    />
                </motion.div>

                {/* Close Button */}
                <button
                    onClick={onClose}
                    className="absolute top-4 right-4 text-white bg-black/40 p-3 rounded-full hover:bg-black/60 transition-colors"
                    aria-label="Close image viewer"
                >
                    <X className="w-6 h-6" />
                </button>

                {/* Controls */}
                <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-2 text-white bg-black/40 p-2 rounded-full backdrop-blur-sm">
                    <button onClick={(e) => { e.stopPropagation(); handleZoom('out'); }} className="p-2 hover:bg-white/20 rounded-full transition-colors disabled:opacity-50" disabled={scale <= 1} aria-label="Zoom out">
                        <ZoomOut className="w-5 h-5" />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleZoom('in'); }} className="p-2 hover:bg-white/20 rounded-full transition-colors disabled:opacity-50" disabled={scale >= 8} aria-label="Zoom in">
                        <ZoomIn className="w-5 h-5" />
                    </button>
                    {scale > 1 && (
                        <>
                            <div className="w-px h-5 bg-white/30 mx-1"></div>
                            <button onClick={(e) => { e.stopPropagation(); handleZoom('reset'); }} className="p-2 hover:bg-white/20 rounded-full transition-colors" aria-label="Reset zoom">
                                <RotateCcw className="w-5 h-5" />
                            </button>
                        </>
                    )}
                </div>
                
                {/* Image Credits */}
                 {image.author && image.author !== 'N/A' && image.author !== 'Placeholder' && (
                    <div className="absolute bottom-5 left-5 text-white/90 text-xs bg-black/30 px-3 py-1.5 rounded-lg backdrop-blur-sm pointer-events-none">
                        Photo by <strong>{image.author}</strong> on <strong>{image.source}</strong>
                    </div>
                 )}
            </motion.div>
        )}
    </AnimatePresence>
  );
};

export default ImageLightbox;