
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Compass, Map, Home, User as UserIcon, LogOut, PlusCircle, ChevronsUpDown, Bookmark, CalendarDays } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../../context/AppContext.tsx';

const NavLink = ({ to, children, text }: { to: string, children: React.ReactNode, text: string }) => {
    const location = useLocation();
    const isActive = location.pathname === to || (to === '/events' && location.pathname.startsWith('/event/'));
    return (
        <Link to={to} className="relative flex items-center gap-2 transition-colors duration-300 text-slate-500 hover:text-[#1C3A3A]">
            <div className={isActive ? 'text-[#FF712F]' : ''}>{children}</div>
            <span className={`text-sm font-medium ${isActive ? 'text-[#1C3A3A] font-semibold' : 'text-slate-500'}`}>{text}</span>
        </Link>
    );
}

const UserMenu = () => {
    const { user, isAdmin, signOut } = useAppContext();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);

    const handleSignOut = async () => {
        await signOut();
        navigate('/');
    };
    
    if (!user || user.isAnonymous) {
        return <Link to="/login" className="text-sm font-semibold text-[#1C3A3A] bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-full transition-colors">Login</Link>;
    }

    return (
        <div className="relative">
            <button onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-2 p-2 rounded-full bg-slate-100 hover:bg-slate-200 transition-colors">
                <UserIcon className="w-5 h-5 text-slate-600" />
                <ChevronsUpDown className="w-4 h-4 text-slate-500" />
            </button>
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-2xl shadow-black/10 border border-slate-100 p-2 z-30"
                    >
                        {isAdmin && (
                             <Link to="/add-place" onClick={() => setIsOpen(false)} className="flex items-center gap-3 w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 hover:text-[#1C3A3A] rounded-md transition-colors">
                                <PlusCircle className="w-4 h-4"/>
                                Add Place
                            </Link>
                        )}
                        <button onClick={handleSignOut} className="flex items-center gap-3 w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 hover:text-[#1C3A3A] rounded-md transition-colors">
                            <LogOut className="w-4 h-4" />
                            Logout
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};


export default function Header() {
    const { user, isAuthLoading } = useAppContext();

    return (
        <header className="sticky top-0 lg:rounded-t-3xl bg-[#FDFCF9]/80 backdrop-blur-xl z-20 border-b border-slate-200/60">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-10">
                <div className="flex justify-between items-center h-24">
                    <Link to="/" className="flex items-center gap-3">
                        <Compass className="w-8 h-8 text-[#FF712F]" />
                        <div>
                            <p className="font-lora text-2xl font-bold text-[#FF712F] tracking-tight">
                                EC Compass
                            </p>
                            <p className="text-xs text-slate-400 -mt-1">San Francisco Guide</p>
                        </div>
                    </Link>
                    <nav className="flex items-center gap-6 sm:gap-8">
                        <NavLink to="/" text="Home">
                            <Home className="w-5 h-5" />
                        </NavLink>
                        <NavLink to="/map" text="Map">
                            <Map className="w-5 h-5" />
                        </NavLink>
                        {user && !user.isAnonymous && (
                           <>
                             <NavLink to="/bucket-list" text="My List">
                                <Bookmark className="w-5 h-5" />
                             </NavLink>
                             <NavLink to="/events" text="Events">
                                <CalendarDays className="w-5 h-5" />
                             </NavLink>
                           </>
                        )}
                        {!isAuthLoading && <UserMenu />}
                    </nav>
                </div>
            </div>
        </header>
    );
}