import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  className?: string;
}

export const Badge = ({ children, className }: BadgeProps) => (
  <span
    className={`inline-block px-2.5 py-1 text-xs font-semibold rounded-md bg-[#1C3A3A]/5 text-[#1C3A3A]/80 ${className}`}
  >
    {children}
  </span>
);