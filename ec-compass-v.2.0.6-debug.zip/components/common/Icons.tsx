import React from 'react';
import { Camera, Gift, Coffee, Music, Moon, Heart, ChevronRight, MapPin, Clock, DollarSign, Star, Sparkles, BookOpen, User, Users, PartyPopper, MicOff, MessageCircle, UserPlus, Wifi, Wand2, Footprints, Award, GraduationCap, Briefcase, Compass, Home, Target, MessagesSquare, UtensilsCrossed, Bookmark, CalendarDays, Sun, Lightbulb, Cloud, Wind, CloudRain } from 'lucide-react';
import { VibeType } from '../../types.ts';

const icons = {
  Camera,
  Gift,
  Coffee,
  Music,
  Moon,
  Heart,
  ChevronRight,
  MapPin,
  Clock,
  DollarSign,
  Star,
  Sparkles,
  BookOpen,
  User,
  Users,
  PartyPopper,
  MicOff,
  MessageCircle,
  UserPlus,
  Wifi,
  Wand2,
  Footprints,
  Award,
  GraduationCap,
  Briefcase,
  Compass,
  Home,
  Target,
  MessagesSquare,
  UtensilsCrossed,
  Bookmark,
  CalendarDays,
  Sun,
  Lightbulb,
  Cloud,
  Wind,
  CloudRain,
};

interface IconProps {
  type: VibeType;
  className?: string;
  style?: React.CSSProperties;
}

const VibeIcon = ({ type, className, style }: IconProps) => {
  const IconComponent = icons[type];
  if (!IconComponent) return null;
  return <IconComponent className={className} style={style} />;
};

export default VibeIcon;