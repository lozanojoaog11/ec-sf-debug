import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { getEventCommentsStream } from '../services/firebaseService.ts';
import { EventComment } from '../types.ts';
import { useAppContext } from '../context/AppContext.tsx';
import { Send, MessageSquare } from 'lucide-react';
import { Skeleton } from './common/Skeleton.tsx';

const CommentBubble = ({ comment, isOwn }: { comment: EventComment, isOwn: boolean }) => {
    const commentDate = new Date(comment.createdAt);
    const formattedTime = commentDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true });

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-end gap-2.5 ${isOwn ? 'justify-end' : 'justify-start'}`}
        >
            {!isOwn && (
                <img
                    src={comment.createdBy.photoURL}
                    alt={comment.createdBy.firstName}
                    className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                />
            )}
            <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${isOwn ? 'bg-[#1C3A3A] text-white rounded-br-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'}`}>
                {!isOwn && <p className="font-bold text-sm text-[#FF712F] mb-0.5">{comment.createdBy.firstName}</p>}
                <p className="text-sm leading-snug whitespace-pre-wrap">{comment.text}</p>
                <p className={`text-xs mt-1.5 ${isOwn ? 'text-slate-300' : 'text-slate-400'} text-right`}>{formattedTime}</p>
            </div>
        </motion.div>
    )
};

interface EventCommentsProps {
    eventId: string;
}

const EventComments: React.FC<EventCommentsProps> = ({ eventId }) => {
    const { user, addEventComment } = useAppContext();
    const [comments, setComments] = useState<EventComment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const commentsEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setIsLoading(true);
        const unsubscribe = getEventCommentsStream(eventId, (fetchedComments) => {
            setComments(fetchedComments);
            setIsLoading(false);
        });

        return () => unsubscribe();
    }, [eventId]);

    useEffect(() => {
        commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [comments]);


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedComment = newComment.trim();
        if (trimmedComment) {
            try {
                await addEventComment(eventId, trimmedComment);
                setNewComment('');
            } catch (error) {
                console.error("Failed to add comment", error);
            }
        }
    };

    return (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80">
            <h3 className="font-lora text-xl font-bold text-[#1C3A3A] flex items-center gap-2 mb-4">
                <MessageSquare className="w-5 h-5" />
                Live Chat & Comments
            </h3>
            
            <div className="h-80 overflow-y-auto space-y-4 p-4 bg-slate-50 rounded-lg">
                {isLoading ? (
                    <div className="space-y-4">
                        <Skeleton className="h-16 w-3/4" />
                        <Skeleton className="h-16 w-3/4 ml-auto" />
                        <Skeleton className="h-16 w-3/4" />
                    </div>
                ) : comments.length > 0 ? (
                    <AnimatePresence>
                        {comments.map(comment => (
                            <CommentBubble key={comment.id} comment={comment} isOwn={user?.uid === comment.createdBy.uid} />
                        ))}
                    </AnimatePresence>
                ) : (
                    <div className="flex items-center justify-center h-full text-slate-400">
                        <p>No comments yet. Be the first to say something!</p>
                    </div>
                )}
                 <div ref={commentsEndRef} />
            </div>

            <form onSubmit={handleSubmit} className="mt-4 flex items-center gap-3">
                <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    disabled={!user || user.isAnonymous}
                    className="flex-1 p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] transition disabled:bg-slate-100"
                />
                <button
                    type="submit"
                    disabled={!user || user.isAnonymous || newComment.trim() === ''}
                    className="w-12 h-12 flex items-center justify-center bg-[#1C3A3A] text-white rounded-xl hover:bg-opacity-90 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
                >
                    <Send className="w-5 h-5" />
                </button>
            </form>
        </div>
    );
};

export default EventComments;