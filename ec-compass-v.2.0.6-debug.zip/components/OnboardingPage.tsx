
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../context/AppContext.tsx';
import { updateUserProfile, createPublicUserProfile } from '../services/firebaseService.ts';
import { UserProfile } from '../types.ts';
import VibeIcon, { VibeType } from './common/Icons.tsx';
import { LoaderCircle } from 'lucide-react';

const containerVariants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const itemVariants = { hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } };

const OptionCard: React.FC<{ icon: VibeType; title: string; description: string; onClick: () => void; }> = ({ icon, title, description, onClick }) => (
    <motion.button variants={itemVariants} onClick={onClick} whileHover={{ y: -5 }} whileTap={{ scale: 0.98 }}
        className="w-full p-6 text-left bg-white rounded-2xl border-2 border-slate-200/80 hover:border-[#1C3A3A] hover:bg-[#1C3A3A]/5 focus:border-[#1C3A3A] transition-all duration-300 group">
        <div className="flex items-center gap-5">
            <div className="flex-shrink-0 w-14 h-14 bg-[#FF712F]/20 rounded-xl flex items-center justify-center transition-colors duration-300 group-hover:bg-[#FF712F]/30">
                <VibeIcon type={icon} className="w-8 h-8 text-[#FF712F]" />
            </div>
            <div>
                <h3 className="text-lg font-bold text-[#1C3A3A]">{title}</h3>
                <p className="text-sm text-slate-500">{description}</p>
            </div>
        </div>
    </motion.button>
);

const OnboardingStep: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <motion.div className="w-full" initial={{ x: 300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -300, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 260, damping: 25 }}>
        {children}
    </motion.div>
);

export default function OnboardingPage() {
    const { user, userProfile } = useAppContext();
    const [step, setStep] = useState(1);
    const [answers, setAnswers] = useState<Partial<UserProfile>>({
        firstName: userProfile?.firstName || user?.displayName?.split(' ')[0] || '',
        country: userProfile?.country || '',
        school: userProfile?.school || 'EC San Francisco',
        class: userProfile?.class || ''
    });
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if(userProfile) {
            setAnswers(prev => ({
                ...prev,
                firstName: userProfile.firstName || user?.displayName?.split(' ')[0] || '',
                country: userProfile.country || '',
                school: userProfile.school || 'EC San Francisco',
                class: userProfile.class || ''
            }));
        }
    }, [userProfile, user]);

    const handleAnswer = (key: keyof UserProfile, value: any) => {
        setAnswers(prev => ({ ...prev, [key]: value }));
        if (step < 5) setStep(step + 1);
    };

    const handleFinalSubmit = async (e?: React.FormEvent) => {
        e?.preventDefault();
        if (user && answers.firstName && answers.country && answers.school) {
            setIsLoading(true);
            try {
                const finalProfileData: Partial<UserProfile> = {
                     ...answers, onboardingCompleted: true 
                };
                await updateUserProfile(user.uid, finalProfileData);
                await createPublicUserProfile(user, finalProfileData);
                // The AppContext listener will handle the transition
            } catch (error) {
                console.error("Failed to save onboarding data:", error);
                setIsLoading(false);
            }
        }
    };
    
    const progress = Math.round((step / 5) * 100);
    const EC_SCHOOLS = ["EC San Francisco", "EC Los Angeles", "EC San Diego", "EC New York", "EC Boston", "EC Miami", "EC Toronto", "EC Vancouver", "EC Montreal", "EC London", "EC Cambridge", "EC Oxford", "EC Brighton", "EC Bristol", "EC Manchester", "EC Dublin", "EC Malta", "EC Cape Town"];

    return (
        <div className="min-h-screen bg-[#FDFCF9] flex flex-col items-center justify-center p-4 sm:p-6 lg:p-10">
            <div className="w-full max-w-2xl mx-auto">
                 <div className="mb-8 px-2">
                    <p className="text-sm font-semibold text-center text-slate-500 mb-2">Step {step} of 5</p>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                        <motion.div className="bg-[#1C3A3A] h-2 rounded-full"
                            initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ ease: "easeInOut", duration: 0.5 }} />
                    </div>
                 </div>

                <AnimatePresence mode="wait">
                    {step === 1 && (
                        <OnboardingStep key={1}>
                             <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center space-y-6">
                                <motion.h1 variants={itemVariants} className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A]">How do you feel about your English?</motion.h1>
                                <motion.p variants={itemVariants} className="text-slate-500 text-lg max-w-xl mx-auto">This helps us recommend places where you'll feel most comfortable.</motion.p>
                                <div className="space-y-4 pt-4">
                                    <OptionCard icon="Award" title="Confident" description="Ready for anything, from fast-paced bars to local debates." onClick={() => handleAnswer('englishLevel', 'confident')} />
                                    <OptionCard icon="GraduationCap" title="Getting There" description="I can handle daily conversations and ordering food." onClick={() => handleAnswer('englishLevel', 'getting-there')} />
                                    <OptionCard icon="BookOpen" title="Just Starting" description="I'm still learning and prefer patient, simple interactions." onClick={() => handleAnswer('englishLevel', 'starting')} />
                                </div>
                            </motion.div>
                        </OnboardingStep>
                    )}
                    {step === 2 && (
                        <OnboardingStep key={2}>
                             <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center space-y-6">
                                <motion.h1 variants={itemVariants} className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A]">What's your main vibe?</motion.h1>
                                <motion.p variants={itemVariants} className="text-slate-500 text-lg max-w-xl mx-auto">Are you here to explore, socialize, or learn?</motion.p>
                                <div className="space-y-4 pt-4">
                                    <OptionCard icon="Compass" title="Explorer" description="Show me hidden gems and unique adventures." onClick={() => handleAnswer('userVibe', 'explorer')} />
                                    <OptionCard icon="Users" title="Socializer" description="I want to meet people and find group activities." onClick={() => handleAnswer('userVibe', 'socializer')} />
                                    <OptionCard icon="Sparkles" title="Learner" description="I'm looking for cultural and educational experiences." onClick={() => handleAnswer('userVibe', 'learner')} />
                                </div>
                            </motion.div>
                        </OnboardingStep>
                    )}
                    {step === 3 && (
                        <OnboardingStep key={3}>
                            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center space-y-6">
                                <motion.h1 variants={itemVariants} className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A]">How long are you in SF?</motion.h1>
                                <motion.p variants={itemVariants} className="text-slate-500 text-lg max-w-xl mx-auto">We'll prioritize the must-sees or the deep cuts.</motion.p>
                                <div className="space-y-4 pt-4">
                                    <OptionCard icon="Briefcase" title="Just Visiting (1-4 weeks)" description="Show me the highlights and iconic spots!" onClick={() => handleAnswer('stayDuration', 'short')} />
                                    <OptionCard icon="Heart" title="Getting Settled (1-6 months)" description="A mix of famous places and local favorites." onClick={() => handleAnswer('stayDuration', 'medium')} />
                                    <OptionCard icon="Home" title="Living Like a Local (6+ months)" description="Help me uncover the real, everyday San Francisco." onClick={() => handleAnswer('stayDuration', 'long')} />
                                </div>
                            </motion.div>
                        </OnboardingStep>
                    )}
                    {step === 4 && (
                         <OnboardingStep key={4}>
                            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center space-y-6">
                                <motion.h1 variants={itemVariants} className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A]">Complete Your Profile</motion.h1>
                                <motion.p variants={itemVariants} className="text-slate-500 text-lg max-w-xl mx-auto">This helps you connect with other students. It will be visible to the EC community.</motion.p>
                                <form onSubmit={(e) => { e.preventDefault(); setStep(5); }} className="space-y-4 pt-4 text-left">
                                     <div>
                                        <label htmlFor="firstName" className="text-sm font-semibold text-slate-700">First Name</label>
                                        <input id="firstName" type="text" value={answers.firstName} onChange={e => setAnswers(prev => ({...prev, firstName: e.target.value}))} required className="mt-2 block w-full px-4 py-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] transition" />
                                     </div>
                                      <div>
                                        <label htmlFor="country" className="text-sm font-semibold text-slate-700">Home Country</label>
                                        <input id="country" type="text" value={answers.country} onChange={e => setAnswers(prev => ({...prev, country: e.target.value}))} required className="mt-2 block w-full px-4 py-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] transition" />
                                     </div>
                                      <div>
                                        <label htmlFor="school" className="text-sm font-semibold text-slate-700">Your EC School</label>
                                        <select id="school" value={answers.school} onChange={e => setAnswers(prev => ({...prev, school: e.target.value}))} required className="mt-2 block w-full px-4 py-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] transition">
                                            {EC_SCHOOLS.map(s => <option key={s} value={s}>{s}</option>)}
                                        </select>
                                     </div>
                                     <div className="pt-4">
                                         <button type="submit" disabled={!answers.firstName || !answers.country || !answers.school} className="w-full bg-[#1C3A3A] text-white font-semibold px-6 py-4 rounded-xl hover:bg-opacity-90 disabled:bg-slate-300 transition-colors text-lg">
                                            Next
                                         </button>
                                     </div>
                                </form>
                            </motion.div>
                        </OnboardingStep>
                    )}
                    {step === 5 && (
                         <OnboardingStep key={5}>
                            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="text-center space-y-6">
                                <motion.h1 variants={itemVariants} className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A]">One Last Thing...</motion.h1>
                                <motion.p variants={itemVariants} className="text-slate-500 text-lg max-w-xl mx-auto">This helps other students in your class find you.</motion.p>
                                <form onSubmit={handleFinalSubmit} className="space-y-4 pt-4 text-left">
                                     <div>
                                        <label htmlFor="class" className="text-sm font-semibold text-slate-700">Which class are you in? (e.g., "Pre-Intermediate A")</label>
                                        <input id="class" type="text" value={answers.class} onChange={e => setAnswers(prev => ({...prev, class: e.target.value}))} required className="mt-2 block w-full px-4 py-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] transition" placeholder="Optional, but recommended" />
                                     </div>
                                     <div className="pt-4">
                                         <button type="submit" disabled={isLoading} className="w-full bg-[#1C3A3A] text-white font-semibold px-6 py-4 rounded-xl hover:bg-opacity-90 disabled:bg-slate-300 transition-colors text-lg">
                                            Let's Go!
                                         </button>
                                     </div>
                                </form>
                             </motion.div>
                        </OnboardingStep>
                    )}
                </AnimatePresence>
                
                {isLoading && (
                    <div className="absolute inset-0 bg-[#FDFCF9]/80 backdrop-blur-sm flex flex-col items-center justify-center z-10">
                        <LoaderCircle className="w-12 h-12 text-[#1C3A3A] animate-spin" />
                        <p className="mt-4 font-semibold text-[#1C3A3A]">Building your Compass...</p>
                    </div>
                )}
            </div>
        </div>
    );
}