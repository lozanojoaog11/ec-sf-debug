
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Place, Image } from '../types.ts';
import { addPlace } from '../services/firebaseService.ts';

const InputField = ({ id, label, value, onChange, placeholder, required = true, type = 'text' }: any) => (
    <div>
        <label htmlFor={id} className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
        <input
            type={type}
            id={id}
            name={id}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            required={required}
            step={type === 'number' ? 'any' : undefined}
            className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] focus:border-[#1C3A3A] transition"
        />
    </div>
);

const TextareaField = ({ id, label, value, onChange, placeholder, required = true }: any) => (
     <div>
        <label htmlFor={id} className="block text-sm font-semibold text-slate-700 mb-2">{label}</label>
        <textarea
            id={id}
            name={id}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            required={required}
            rows={3}
            className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-[#1C3A3A] focus:border-[#1C3A3A] transition"
        />
    </div>
);


export default function AddPlacePage() {
    const [formData, setFormData] = useState({
        name: '',
        category: '',
        images: '',
        location: { address: '', neighborhood: '', walkFromEC: '', coordinates: { lat: '', lng: '' } },
        pricing: { range: '', average: '' },
        details: { description: '', hours: '', bestTime: '', whySpecial: '', funFacts: '', localTip: '' },
        englishCorner: { conversationStarters: '', usefulPhrases: '', culturalContext: '' },
        tags: { vibeTags: '', bestFor: '' },
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        const keys = name.split('.');

        if (keys.length > 1) {
             setFormData(prev => {
                const newState = JSON.parse(JSON.stringify(prev)); // Deep copy
                let current: any = newState;
                for (let i = 0; i < keys.length - 1; i++) {
                    current = current[keys[i]];
                }
                current[keys[keys.length - 1]] = value;
                return newState;
            });
        } else {
            setFormData(prev => ({ ...prev, [name]: value as any }));
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        setSuccess('');

        try {
            const imageUrls = formData.images.split(',').map(s => s.trim()).filter(Boolean);
            const imagesData: Image[] = imageUrls.map(url => ({
                url: url,
                thumb: url, // For simplicity, use full URL as thumb. Can be optimized later.
                author: 'N/A',
                source: 'Uploaded by Admin'
            }));

            const placeData: Omit<Place, 'id' | 'imageUrl'> = {
                name: formData.name,
                category: formData.category,
                images: imagesData,
                location: {
                    ...formData.location,
                    coordinates: {
                        lat: parseFloat(formData.location.coordinates.lat),
                        lng: parseFloat(formData.location.coordinates.lng),
                    }
                },
                 pricing: {
                    ...formData.pricing
                },
                details: {
                    ...formData.details,
                    funFacts: formData.details.funFacts.split(',').map(s => s.trim()).filter(Boolean),
                },
                englishCorner: {
                    ...formData.englishCorner,
                    conversationStarters: formData.englishCorner.conversationStarters.split(',').map(s => s.trim()).filter(Boolean),
                    usefulPhrases: formData.englishCorner.usefulPhrases.split(',').map(s => s.trim()).filter(Boolean),
                },
                tags: {
                    vibeTags: formData.tags.vibeTags.split(',').map(s => s.trim()).filter(Boolean),
                    bestFor: formData.tags.bestFor.split(',').map(s => s.trim()).filter(Boolean),
                }
            };

            if (isNaN(placeData.location.coordinates.lat) || isNaN(placeData.location.coordinates.lng)) {
                throw new Error("Latitude and Longitude must be valid numbers.");
            }

            const newId = await addPlace(placeData as Omit<Place, 'id'>);
            setSuccess(`Place "${formData.name}" added successfully!`);
            setTimeout(() => navigate(`/place/${newId}`), 1500);
        } catch (err: any) {
            setError(err.message || 'Failed to add place.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A] tracking-tight mb-8">Add New Place</h1>
            <form onSubmit={handleSubmit} className="space-y-8 p-8 bg-white rounded-2xl shadow-xl shadow-slate-200/40 border border-slate-200/80">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <InputField id="name" label="Place Name" value={formData.name} onChange={handleChange} placeholder="e.g., Dolores Park" />
                    <InputField id="category" label="Category" value={formData.category} onChange={handleChange} placeholder="e.g., Parks & Nature" />
                </div>
                <TextareaField id="images" label="Image URLs (comma-separated)" value={formData.images} onChange={handleChange} placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg" required={false} />

                <fieldset className="space-y-4 border-t pt-6">
                    <legend className="font-lora text-2xl font-bold text-slate-700 mb-2">Location</legend>
                    <InputField id="location.address" label="Address" value={formData.location.address} onChange={handleChange} placeholder="e.g., Dolores St & 19th St" />
                    <InputField id="location.neighborhood" label="Neighborhood" value={formData.location.neighborhood} onChange={handleChange} placeholder="e.g., Mission District" />
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <InputField id="location.coordinates.lat" label="Latitude" value={formData.location.coordinates.lat} onChange={handleChange} placeholder="e.g., 37.7597" type="number"/>
                        <InputField id="location.coordinates.lng" label="Longitude" value={formData.location.coordinates.lng} onChange={handleChange} placeholder="e.g., -122.4271" type="number"/>
                    </div>
                    <InputField id="location.walkFromEC" label="Walk from EC" value={formData.location.walkFromEC} onChange={handleChange} placeholder="e.g., 25 min walk" />
                </fieldset>
                
                <fieldset className="space-y-4 border-t pt-6">
                    <legend className="font-lora text-2xl font-bold text-slate-700 mb-2">Pricing</legend>
                    <InputField id="pricing.range" label="Price Range" value={formData.pricing.range} onChange={handleChange} placeholder="e.g., $$-$$$" />
                    <InputField id="pricing.average" label="Average Price" value={formData.pricing.average} onChange={handleChange} placeholder="e.g., $25-40 per person" />
                </fieldset>

                <fieldset className="space-y-4 border-t pt-6">
                    <legend className="font-lora text-2xl font-bold text-slate-700 mb-2">Details</legend>
                    <TextareaField id="details.description" label="Description" value={formData.details.description} onChange={handleChange} placeholder="A vibrant park..." />
                    <InputField id="details.hours" label="Hours" value={formData.details.hours} onChange={handleChange} placeholder="e.g., 6am - 10pm" />
                    <InputField id="details.bestTime" label="Best Time to Go" value={formData.details.bestTime} onChange={handleChange} placeholder="e.g., Weekend afternoons" />
                    <TextareaField id="details.whySpecial" label="Why It's Special" value={formData.details.whySpecial} onChange={handleChange} placeholder="The people-watching is epic..." />
                    <TextareaField id="details.localTip" label="Local Tip" value={formData.details.localTip} onChange={handleChange} placeholder="Grab a burrito from..." />
                    <InputField id="details.funFacts" label="Fun Facts (comma-separated)" value={formData.details.funFacts} onChange={handleChange} placeholder="Fact 1, Fact 2" />
                </fieldset>

                <fieldset className="space-y-4 border-t pt-6">
                    <legend className="font-lora text-2xl font-bold text-slate-700 mb-2">Tags (comma-separated)</legend>
                     <InputField id="tags.vibeTags" label="Vibe Tags" value={formData.tags.vibeTags} onChange={handleChange} placeholder="e.g., free, views, sunny, #picnic, #social" />
                     <InputField id="tags.bestFor" label="Best For Tags (optional)" value={formData.tags.bestFor} onChange={handleChange} placeholder="e.g., adventurous foodies, special occasions" required={false} />
                </fieldset>
                
                <fieldset className="space-y-4 border-t pt-6">
                    <legend className="font-lora text-2xl font-bold text-slate-700 mb-2">English Corner (comma-separated for lists)</legend>
                    <TextareaField id="englishCorner.conversationStarters" label="Conversation Starters" value={formData.englishCorner.conversationStarters} onChange={handleChange} placeholder="Starter 1, Starter 2" />
                    <TextareaField id="englishCorner.usefulPhrases" label="Useful Phrases" value={formData.englishCorner.usefulPhrases} onChange={handleChange} placeholder="Phrase 1, Phrase 2" />
                    <TextareaField id="englishCorner.culturalContext" label="Cultural Context" value={formData.englishCorner.culturalContext} onChange={handleChange} placeholder="It's a cultural hub..." />
                </fieldset>
                
                {error && <p className="text-red-600 text-sm text-center p-3 bg-red-50 rounded-lg">{error}</p>}
                {success && <p className="text-green-600 text-sm text-center p-3 bg-green-50 rounded-lg">{success}</p>}

                <div className="pt-6 border-t">
                    <button type="submit" disabled={isLoading} className="w-full bg-[#1C3A3A] text-white font-semibold px-6 py-4 rounded-xl hover:bg-opacity-90 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors text-lg">
                        {isLoading ? 'Saving...' : 'Add Place to Compass'}
                    </button>
                </div>
            </form>
        </div>
    );
}