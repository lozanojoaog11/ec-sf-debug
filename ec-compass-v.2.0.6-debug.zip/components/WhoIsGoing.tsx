
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getInterestedUserIdsBySchool, getPublicUserProfiles } from '../services/firebaseService.ts';
import { PublicUserProfile } from '../types.ts';
import { Skeleton } from './common/Skeleton.tsx';
import { Users, Plus } from 'lucide-react';
import { useAppContext } from '../context/AppContext.tsx';

const Avatar = ({ profile }: { profile: PublicUserProfile }) => (
    <div className="group relative">
        <img
            src={profile.photoURL}
            alt={profile.firstName}
            className="w-12 h-12 rounded-full object-cover border-2 border-white"
        />
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-[#1C3A3A] text-white text-xs font-semibold px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
            {profile.firstName}
            <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-[#1C3A3A]"></div>
        </div>
    </div>
);

interface WhoIsGoingProps {
  placeId: string;
  onPlanEvent: () => void;
}

const WhoIsGoing: React.FC<WhoIsGoingProps> = ({ placeId, onPlanEvent }) => {
    const { user, userProfile } = useAppContext();
    const [interestedUsers, setInterestedUsers] = useState<PublicUserProfile[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchInterest = async () => {
            if (!userProfile?.school) {
                setIsLoading(false);
                return;
            }
            setIsLoading(true);
            try {
                const userIds = await getInterestedUserIdsBySchool(placeId, userProfile.school);
                const otherUserIds = userIds.filter(uid => uid !== user?.uid);
                
                if (otherUserIds.length > 0) {
                    const profiles = await getPublicUserProfiles(otherUserIds);
                    setInterestedUsers(profiles);
                } else {
                    setInterestedUsers([]);
                }
            } catch (error) {
                console.error("Failed to fetch interested users:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchInterest();
    }, [placeId, user?.uid, userProfile?.school]);

    if (isLoading) {
        return (
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/50">
                <Skeleton className="h-6 w-1/3 mb-4" />
                <div className="flex items-center -space-x-4">
                    <Skeleton className="w-12 h-12 rounded-full" />
                    <Skeleton className="w-12 h-12 rounded-full" />
                    <Skeleton className="w-12 h-12 rounded-full" />
                </div>
            </div>
        );
    }
    
    // Show the component even if there are no "other" users, to allow the current user to initiate an event.
    if (!userProfile?.school) return null;


    const canCreateEvent = interestedUsers.length >= 2; // 2 others + current user = 3+

    return (
        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-50/70 p-5 rounded-2xl border border-slate-200/50"
        >
            <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h3 className="font-lora text-xl font-bold text-[#1C3A3A] flex items-center gap-2">
                        <Users className="w-5 h-5 text-slate-500" />
                        Community Interest
                    </h3>
                    <p className="text-sm text-slate-500 mt-1">Join other students from {userProfile.school} interested in this spot.</p>
                </div>
                {canCreateEvent && (
                    <button onClick={onPlanEvent} className="bg-[#FF712F] text-white font-semibold px-5 py-2.5 rounded-full hover:bg-opacity-90 transition-colors text-sm shadow-md shadow-[#FF712F]/20">
                        Create Event
                    </button>
                )}
            </div>

             {interestedUsers.length > 0 && (
                <div className="flex items-center mt-4">
                    <div className="flex -space-x-3 pr-4">
                        {interestedUsers.slice(0,5).map(profile => (
                            <Avatar key={profile.uid} profile={profile} />
                        ))}
                    </div>
                    {interestedUsers.length > 5 && (
                        <div className="text-sm font-semibold text-slate-500">
                            + {interestedUsers.length - 5} more
                        </div>
                    )}
                </div>
            )}
            {interestedUsers.length < 2 && (
                 <p className="text-sm text-slate-500 mt-3 text-center bg-slate-100 p-3 rounded-lg">Be the first to create an event for this place!</p>
            )}
             {!canCreateEvent && (
                <div className="text-center mt-4">
                     <button onClick={onPlanEvent} className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-full hover:bg-slate-300 transition-colors text-sm">
                        Plan a Visit
                    </button>
                </div>
            )}
        </motion.div>
    );
};

export default WhoIsGoing;