
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext.tsx';
import { Skeleton } from './common/Skeleton.tsx';

const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAdmin, isAuthLoading } = useAppContext();
  const location = useLocation();

  if (isAuthLoading) {
    return (
        <div className="space-y-8">
            <Skeleton className="h-16 w-3/4 mb-8" />
            <Skeleton className="h-64 w-full" />
        </div>
    );
  }

  if (!isAdmin) {
    // If the user is not an admin, redirect them to the home page.
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default AdminRoute;