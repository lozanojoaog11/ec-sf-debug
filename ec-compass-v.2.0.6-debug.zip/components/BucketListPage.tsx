
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../context/AppContext.tsx';
import { Place, BucketListItem } from '../types.ts';
import { Check, Calendar, X, Trash2, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const TABS = ['Want to Go', 'Been There'];

const ProfileCompletionBanner = ({ onComplete }: { onComplete: () => void }) => (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-5 rounded-r-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
                <h4 className="font-bold text-amber-800">Unlock Social Features</h4>
                <p className="text-sm text-amber-700">Please complete your profile by adding your school to see who else is going and plan visits.</p>
            </div>
        </div>
        <button onClick={onComplete} className="bg-amber-500 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors flex-shrink-0">
            Complete Profile
        </button>
    </div>
);

const BucketListItemCard = ({ place, item, onRemove, onUpdate }: { place: Place, item: BucketListItem, onRemove: () => void, onUpdate: (data: Partial<BucketListItem>) => void }) => {
    const navigate = useNavigate();
    const [isScheduling, setIsScheduling] = useState(false);
    const [scheduleDate, setScheduleDate] = useState(item.scheduledDate || '');
    
    const handleScheduleSave = () => {
        onUpdate({ scheduledDate: scheduleDate || null });
        setIsScheduling(false);
    }
    
    const today = new Date().toISOString().split('T')[0];

    return (
        <motion.div 
            layout="position"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ type: 'spring', stiffness: 250, damping: 25 }}
            className="flex items-center gap-4 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-sm"
        >
            <img 
                src={place.imageUrl} 
                alt={place.name} 
                className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-xl cursor-pointer"
                onClick={() => navigate(`/place/${place.id}`)}
            />
            <div className="flex-1" onClick={() => navigate(`/place/${place.id}`)}>
                <h3 className="font-bold text-lg text-slate-800 cursor-pointer hover:underline">{place.name}</h3>
                <p className="text-sm text-slate-500">{place.location.neighborhood}</p>
                {item.status === 'want-to-go' && item.scheduledDate && (
                    <p className="text-xs font-semibold text-teal-600 mt-1">🗓️ Planned for {new Date(item.scheduledDate + 'T00:00:00').toLocaleDateString(undefined, { timeZone: 'UTC' })}</p>
                )}
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2">
                {item.status === 'want-to-go' && (
                    <>
                        <button onClick={() => onUpdate({ status: 'been-there' })} className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-100 hover:bg-teal-100 text-slate-500 hover:text-teal-600 transition-colors" title="Mark as 'Been There'">
                            <Check className="w-5 h-5"/>
                        </button>
                        <AnimatePresence>
                            {isScheduling && (
                                <motion.div 
                                    initial={{ width: 0, opacity: 0 }}
                                    animate={{ width: 'auto', opacity: 1 }}
                                    exit={{ width: 0, opacity: 0 }}
                                    className="flex items-center gap-2 overflow-hidden"
                                >
                                    <input type="date" value={scheduleDate} min={today} onChange={e => setScheduleDate(e.target.value)} className="p-2 border rounded-lg text-sm" />
                                    <button onClick={handleScheduleSave} className="p-2 bg-slate-800 text-white rounded-lg">Save</button>
                                    <button onClick={() => setIsScheduling(false)}><X className="w-4 h-4"/></button>
                                </motion.div>
                            )}
                        </AnimatePresence>
                        
                        {!isScheduling && (
                             <button onClick={() => setIsScheduling(true)} className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-100 hover:bg-blue-100 text-slate-500 hover:text-blue-600 transition-colors" title="Schedule a visit">
                                <Calendar className="w-5 h-5"/>
                            </button>
                        )}
                    </>
                )}
                <button onClick={onRemove} className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-100 hover:bg-red-100 text-slate-500 hover:text-red-600 transition-colors" title="Remove from list">
                    <Trash2 className="w-5 h-5"/>
                </button>
            </div>
        </motion.div>
    )
}

export default function BucketListPage() {
    const { bucketList, getPlaceById, removeFromBucketList, updateBucketListItem, userProfile } = useAppContext();
    const [activeTab, setActiveTab] = useState(TABS[0]);
    const navigate = useNavigate();

    const lists = useMemo(() => {
        const wantToGo: { place: Place, item: BucketListItem }[] = [];
        const beenThere: { place: Place, item: BucketListItem }[] = [];

        Object.entries(bucketList).forEach(([placeId, item]) => {
            const place = getPlaceById(placeId);
            if (place) {
                const bucketItem = item as BucketListItem;
                if (bucketItem.status === 'want-to-go') {
                    wantToGo.push({ place, item: bucketItem });
                } else {
                    beenThere.push({ place, item: bucketItem });
                }
            }
        });
        
        wantToGo.sort((a, b) => {
            if (a.item.scheduledDate && !b.item.scheduledDate) return -1;
            if (!a.item.scheduledDate && b.item.scheduledDate) return 1;
            if (a.item.scheduledDate && b.item.scheduledDate) {
                return new Date(a.item.scheduledDate).getTime() - new Date(b.item.scheduledDate).getTime();
            }
            return new Date(b.item.addedAt).getTime() - new Date(a.item.addedAt).getTime();
        });

        beenThere.sort((a, b) => new Date(b.item.addedAt).getTime() - new Date(a.item.addedAt).getTime());

        return { wantToGo, beenThere };
    }, [bucketList, getPlaceById]);
    
    const showProfileBanner = userProfile && !userProfile.school;

    return (
        <div className="space-y-8">
            <h1 className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A] tracking-tight">My Bucket List</h1>

            {showProfileBanner && (
                <ProfileCompletionBanner onComplete={() => navigate('/onboarding')} />
            )}

            <div className="border-b border-slate-200">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    {TABS.map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`whitespace-nowrap py-4 px-1 border-b-2 font-semibold text-md transition-colors ${
                                activeTab === tab
                                ? 'border-[#1C3A3A] text-[#1C3A3A]'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                            }`}
                        >
                            {tab}
                        </button>
                    ))}
                </nav>
            </div>

            <AnimatePresence mode="wait">
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                >
                    {activeTab === 'Want to Go' && (
                        <div className="space-y-4">
                            {lists.wantToGo.length > 0 ? (
                                <AnimatePresence>
                                    {lists.wantToGo.map(({ place, item }) => (
                                        <BucketListItemCard 
                                            key={place.id} 
                                            place={place} 
                                            item={item} 
                                            onRemove={() => removeFromBucketList(place.id)}
                                            onUpdate={(data) => updateBucketListItem(place.id, data)}
                                        />
                                    ))}
                                </AnimatePresence>
                            ) : (
                                <p className="text-center py-20 text-slate-500">Nothing here yet. Explore places and add them to your list!</p>
                            )}
                        </div>
                    )}
                     {activeTab === 'Been There' && (
                        <div className="space-y-4">
                             {lists.beenThere.length > 0 ? (
                                <AnimatePresence>
                                    {lists.beenThere.map(({ place, item }) => (
                                        <BucketListItemCard 
                                            key={place.id} 
                                            place={place} 
                                            item={item} 
                                            onRemove={() => removeFromBucketList(place.id)}
                                            onUpdate={(data) => updateBucketListItem(place.id, data)}
                                        />
                                    ))}
                                </AnimatePresence>
                            ) : (
                                <p className="text-center py-20 text-slate-500">You haven't marked any places as visited yet.</p>
                            )}
                        </div>
                    )}
                </motion.div>
            </AnimatePresence>
        </div>
    )
}