
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getEventById, getEventAttendees } from '../services/firebaseService.ts';
import { Event, PublicUserProfile } from '../types.ts';
import { useAppContext } from '../context/AppContext.tsx';
import { Skeleton } from './common/Skeleton.tsx';
import VibeIcon from './common/Icons.tsx';
import { Calendar, Clock, Users, MapPin, UserCheck, ArrowLeft } from 'lucide-react';
import EventComments from './EventComments.tsx';

const Avatar = ({ profile, size = 'w-12 h-12' }: { profile: PublicUserProfile, size?: string }) => (
    <div className="group relative">
        <img
            src={profile.photoURL}
            alt={profile.firstName}
            className={`${size} rounded-full object-cover border-2 border-white`}
        />
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-[#1C3A3A] text-white text-xs font-semibold px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
            {profile.firstName}
            <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-[#1C3A3A]"></div>
        </div>
    </div>
);

const DetailItem = ({ icon, label, children }: { icon: React.ReactNode, label: string, children: React.ReactNode }) => (
    <div className="flex items-start gap-4">
        <div className="w-10 h-10 flex-shrink-0 bg-slate-100 rounded-lg flex items-center justify-center text-slate-500">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-slate-500">{label}</p>
            <div className="text-md font-semibold text-[#1C3A3A]">{children}</div>
        </div>
    </div>
);


export default function EventDetailPage() {
    const { eventId } = useParams<{ eventId: string }>();
    const { getPlaceById, user, userProfile, rsvpToEvent, isAuthLoading } = useAppContext();
    const [event, setEvent] = useState<Event | null>(null);
    const [attendees, setAttendees] = useState<PublicUserProfile[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    const place = event ? getPlaceById(event.placeId) : null;
    const isAttending = user ? !!attendees.find(a => a.uid === user.uid) : false;

    useEffect(() => {
        if (!eventId) {
            setIsLoading(false);
            return;
        }

        const fetchEventData = async () => {
            setIsLoading(true);
            try {
                const eventData = await getEventById(eventId);
                setEvent(eventData);

                if (eventData) {
                    const attendeeData = await getEventAttendees(eventId);
                    const attendeeProfiles = Object.entries(attendeeData).map(([uid, data]) => ({
                        uid,
                        firstName: data.firstName,
                        photoURL: data.photoURL,
                        school: '', country: '', // Not needed for display
                    }));
                    setAttendees(attendeeProfiles);
                }
            } catch (err) {
                console.error("Failed to fetch event details:", err);
            } finally {
                setIsLoading(false);
            }
        };

        fetchEventData();
    }, [eventId]);

    const handleRsvp = () => {
        if (!eventId || !user || !userProfile) return;
    
        const currentU = user;
        const currentProfile = userProfile;
    
        rsvpToEvent(eventId, isAttending ? 'cant-go' : 'going');
        
        // Optimistic update
        setAttendees(prev => {
            if (isAttending) {
                return prev.filter(a => a.uid !== currentU.uid);
            } else {
                const newAttendee: PublicUserProfile = {
                    uid: currentU.uid,
                    firstName: currentProfile.firstName || 'Student',
                    photoURL: currentU.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${currentProfile.firstName || 'EC'}`,
                    school: currentProfile.school || '',
                    country: currentProfile.country || '',
                    class: currentProfile.class || '',
                };
                return [...prev, newAttendee];
            }
        });
    }


    if (isLoading || isAuthLoading) {
        return (
            <div className="space-y-6">
                <Skeleton className="h-10 w-1/4" />
                <Skeleton className="h-48 w-full rounded-2xl" />
                <Skeleton className="h-12 w-3/4" />
                <div className="grid grid-cols-2 gap-4">
                    <Skeleton className="h-20" />
                    <Skeleton className="h-20" />
                    <Skeleton className="h-20" />
                    <Skeleton className="h-20" />
                </div>
            </div>
        );
    }

    if (!event || !place) {
        return (
            <div className="text-center py-20">
                <h2 className="font-lora text-4xl font-bold text-[#1C3A3A]">Event Not Found</h2>
                <Link to="/events" className="mt-8 inline-block bg-[#1C3A3A] text-white font-bold py-3 px-8 rounded-full hover:bg-opacity-90 transition-colors">
                    Back to Events
                </Link>
            </div>
        );
    }

    const eventDate = new Date(event.dateTime);
    const formattedDate = eventDate.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const formattedTime = eventDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true });
    
    return (
        <div className="space-y-10">
            <div>
                 <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-800 mb-6">
                    <ArrowLeft className="w-4 h-4"/>
                    Back to Events
                </button>
                <div 
                    style={{backgroundImage: `url(${place.imageUrl})`}}
                    className="h-48 bg-cover bg-center rounded-2xl relative flex items-end p-6"
                >
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/20 rounded-2xl"></div>
                    <div className="relative text-white">
                        <p className="font-semibold text-[#FF712F]">{event.vibe}</p>
                        <h1 className="font-lora text-4xl font-bold tracking-tight drop-shadow-lg">{place.name}</h1>
                    </div>
                </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                     <h2 className="font-lora text-2xl font-bold text-[#1C3A3A]">Attendees ({attendees.length} / {event.maxParticipants})</h2>
                     <div className="flex items-center mt-2">
                        <div className="flex -space-x-3 pr-4">
                            {attendees.map(p => <Avatar key={p.uid} profile={p} />)}
                        </div>
                    </div>
                </div>
                <button
                    onClick={handleRsvp}
                    disabled={!user || user.isAnonymous || (attendees.length >= event.maxParticipants && !isAttending)}
                    className={`flex items-center gap-2 px-6 py-3 text-md font-semibold rounded-full transition-colors shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                        isAttending 
                        ? 'bg-teal-500 text-white hover:bg-teal-600 shadow-teal-500/20'
                        : 'bg-slate-800 text-white hover:bg-slate-900 shadow-slate-800/20'
                    }`}
                >
                    <UserCheck className="w-5 h-5"/>
                    {isAttending ? "You're Going!" : "Count me in!"}
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 rounded-2xl border border-slate-200/80">
                <DetailItem icon={<Calendar className="w-5 h-5"/>} label="Date">
                    {formattedDate}
                </DetailItem>
                <DetailItem icon={<Clock className="w-5 h-5"/>} label="Time">
                    {formattedTime}
                </DetailItem>
                <DetailItem icon={<Users className="w-5 h-5"/>} label="Event For">
                    {event.groupPrivacy === 'class' ? 'Classmates Only' : `All ${userProfile?.school || 'EC'} Students`}
                </DetailItem>
                <DetailItem icon={<MapPin className="w-5 h-5"/>} label="Meeting Point">
                    {event.meetingPoint}
                </DetailItem>
                {event.details && (
                     <DetailItem icon={<VibeIcon type="MessageCircle" className="w-5 h-5"/>} label="Details">
                        <p className="whitespace-pre-wrap">{event.details}</p>
                     </DetailItem>
                )}
            </div>

            {eventId && <EventComments eventId={eventId} />}
        </div>
    );
}
