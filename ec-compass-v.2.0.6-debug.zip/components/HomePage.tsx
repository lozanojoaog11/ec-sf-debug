
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../context/AppContext.tsx';
import { getContextualSuggestion } from '../services/geminiService.ts';
import { getWeather } from '../services/weatherService.ts';
import { ContextualSuggestion, Place, Weather, BucketListItem } from '../types.ts';
import PlaceCard from './PlaceCard.tsx';
import { Skeleton } from './common/Skeleton.tsx';
import VibeIcon, { VibeType } from './common/Icons.tsx';
import { VIBES } from '../constants.ts';
import { X } from 'lucide-react';

// --- Contextual Logic ---

interface HomePageContext {
    greeting: string;
    title: string;
    description: string;
    keywords: string[];
}

const getHomePageContext = (): HomePageContext => {
    const hour = new Date().getHours();

    if (hour >= 5 && hour < 12) { // Morning (5am to 11:59am)
        return {
            greeting: "Good morning",
            title: "Start Your Day Right",
            description: "Freshly-brewed coffee and cozy study spots await.",
            keywords: ['morning', 'breakfast', 'am', 'coffee', 'cafe', 'study', 'bakery']
        };
    }
    if (hour >= 12 && hour < 17) { // Afternoon (12pm to 4:59pm)
        return {
            greeting: "Good afternoon",
            title: "Explore Something New",
            description: "Discover hidden gems and iconic views this afternoon.",
            keywords: ['afternoon', 'daytime', 'lunch', 'explore', 'discover', 'view', 'park', 'museum', 'walk', 'iconic']
        };
    }
    if (hour >= 17 && hour < 22) { // Evening (5pm to 9:59pm)
        return {
            greeting: "Good evening",
            title: "Wind Down Your Evening",
            description: "Relax, socialize, and enjoy the city's nightlife.",
            keywords: ['evening', 'night', 'dinner', 'bar', 'music', 'social', 'relax', 'cozy', 'romantic']
        };
    }
    // Late Night (10pm to 4:59am)
    return {
        greeting: "Late night exploring?",
        title: "The City After Dark",
        description: "Find late-night bites and unique spots still open.",
        keywords: ['late', 'night', 'bar', 'cocktail', 'after-hours', 'food', '24/7']
    };
};


// --- Sub-Components ---

const CurrentTime = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 60000); // Update every minute
        return () => clearInterval(timerId);
    }, []);
    return <span className="font-mono">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>;
};

const WeatherBadge = ({ weather }: { weather: Weather | null }) => {
    if (!weather) {
        return <Skeleton className="w-44 h-14 rounded-full" />;
    }
    return (
        <div className="flex items-center gap-3 bg-white px-4 py-2.5 rounded-full border border-slate-200/80 shadow-sm">
            <VibeIcon type={weather.icon} className="w-7 h-7 text-[#FF712F]" />
            <div className="text-left">
                <p className="font-bold text-lg text-slate-800">{weather.temp}°C</p>
                <p className="text-xs text-slate-500 -mt-1">{weather.condition}</p>
            </div>
            <div className="h-8 w-px bg-slate-200 mx-1"></div>
            <div className="text-xl font-semibold text-slate-700">
                <CurrentTime />
            </div>
        </div>
    );
};

const DynamicGreeting = ({ greeting, description, name, weather }: { greeting: string, description: string, name: string | null, weather: Weather | null }) => {
    const isQuestionGreeting = greeting.endsWith('?');
    const finalGreeting = name && !isQuestionGreeting
      ? `${greeting}, ${name}.`
      : greeting;

    return (
        <div className="flex flex-wrap items-start justify-between gap-y-4 gap-x-8">
            <div>
                <h1 className="font-lora text-5xl lg:text-6xl font-bold text-[#1C3A3A] tracking-tight">{finalGreeting}</h1>
                <p className="text-slate-500 text-lg mt-2 max-w-lg">{description}</p>
            </div>
            <div className="pt-2">
                <WeatherBadge weather={weather} />
            </div>
        </div>
    );
};


const TodaysPlanCard = ({ todaysEvent }: { todaysEvent: { place: Place; item: BucketListItem } | null }) => {
    const navigate = useNavigate();

    if (!todaysEvent) {
        return null;
    }

    return (
        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            onClick={() => navigate(`/place/${todaysEvent.place.id}`)}
            className="bg-white p-4 rounded-2xl border border-slate-200/80 flex items-center gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
        >
            <VibeIcon type="CalendarDays" className="w-10 h-10 text-teal-500" />
            <div>
                <p className="text-sm text-teal-600 font-semibold">Today's Plan</p>
                <p className="font-bold text-lg text-slate-800">Visit {todaysEvent.place.name}</p>
            </div>
        </motion.div>
    );
};

const ForYouNow = ({ context }: { context: HomePageContext }) => {
    const { places, getPlaceById, userProfile } = useAppContext();
    const [suggestion, setSuggestion] = useState<ContextualSuggestion | null>(null);
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [aiError, setAiError] = useState('');

    const handleGetSuggestion = async () => {
        setIsAiLoading(true);
        setSuggestion(null);
        setAiError('');
        const result = await getContextualSuggestion(places);
        if (result) {
            setSuggestion(result);
        } else {
            setAiError('Could not get a suggestion. Please try again!');
        }
        setIsAiLoading(false);
    };

    const AILoadingState = () => (
         <div className="flex flex-col items-center justify-center text-center h-full flex-grow">
            <VibeIcon type="Sparkles" className="w-16 h-16 text-[#FF712F] animate-pulse"/>
            <p className="font-lora font-semibold text-xl text-slate-700 mt-4">Thinking of something special...</p>
            <p className="text-slate-500">Please wait a moment.</p>
        </div>
    );

    const AISuggestionState = () => {
        if (!suggestion) return null;
        const recommendedPlaces = suggestion.recommendedPlaceIds.map(id => getPlaceById(id)).filter(p => p) as Place[];

        return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} >
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#FF712F]/20 rounded-xl flex items-center justify-center">
                        <VibeIcon type="Sparkles" className="w-6 h-6 text-[#FF712F]" />
                    </div>
                    <div>
                        <h2 className="font-lora text-2xl font-bold text-[#1C3A3A]">{suggestion.title}</h2>
                        <p className="text-slate-500">{suggestion.description}</p>
                    </div>
                </div>
                <div className="mt-5 -mx-6 px-4 flex gap-5 overflow-x-auto pb-4 snap-x snap-mandatory">
                    {recommendedPlaces.map((place, index) => (
                        <motion.div key={place.id} className="snap-center sm:snap-start w-4/5 sm:w-2/5 lg:w-1/3 flex-shrink-0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1, duration: 0.4 }}>
                            <PlaceCard place={place} />
                        </motion.div>
                    ))}
                </div>
            </motion.div>
        );
    };

    const DefaultState = () => {
        const recommendedPlaces = useMemo(() => {
            const timeFiltered = places.filter(place => {
                const searchableText = [
                    place.details.bestTime,
                    place.category,
                    ...(place.tags.vibeTags || []),
                    ...(place.tags.bestFor || [])
                ].join(' ').toLowerCase();
                return context.keywords.some(keyword => searchableText.includes(keyword));
            });

            if (userProfile?.onboardingCompleted) {
                const getScore = (place: Place): number => {
                    let score = 0;
                    const tags = [...(place.tags.vibeTags || []), place.category, ...(place.tags.bestFor || [])].join(' ').toLowerCase();
                    
                    if (userProfile.englishLevel === 'starting') {
                        if (tags.includes('quiet') || tags.includes('relax') || tags.includes('park') || tags.includes('museum') || tags.includes('cafe')) score += 2;
                    } else if (userProfile.englishLevel === 'confident') {
                        if (tags.includes('social') || tags.includes('lively') || tags.includes('bar') || tags.includes('music')) score += 2;
                    }
                    
                    if (userProfile.userVibe === 'explorer') {
                        if (tags.includes('hidden') || tags.includes('local') || tags.includes('adventure') || tags.includes('unique')) score += 3;
                    } else if (userProfile.userVibe === 'socializer') {
                        if (tags.includes('social') || tags.includes('group') || tags.includes('music') || tags.includes('lively')) score += 3;
                    } else if (userProfile.userVibe === 'learner') {
                        if (tags.includes('culture') || tags.includes('museum') || tags.includes('history') || tags.includes('art')) score += 3;
                    }

                    if (userProfile.stayDuration === 'short') {
                        if (tags.includes('iconic') || tags.includes('must-see') || tags.includes('tourist') || tags.includes('view')) score += 4;
                    } else if (userProfile.stayDuration === 'long') {
                        if (tags.includes('local') || tags.includes('neighborhood') || tags.includes('hidden')) score += 2;
                        if (tags.includes('iconic') || tags.includes('tourist')) score -= 1; // De-prioritize
                    }
                    return score;
                };
                const scoredPlaces = timeFiltered.map(place => ({ place, score: getScore(place) }))
                                          .sort((a, b) => b.score - a.score)
                                          .map(item => item.place);
                return scoredPlaces.slice(0, 5);
            }
            
            if (timeFiltered.length > 0) return timeFiltered.slice(0, 5);
            return places.slice(0, 4); // Fallback

        }, [places, context.keywords, userProfile]);

        if (recommendedPlaces.length === 0) return null;

        const personalizedTitle = userProfile?.onboardingCompleted ? "Tailored For You" : context.title;

        return (
            <motion.div className="flex flex-col flex-grow h-full" initial={{ opacity: 0 }} animate={{ opacity: 1 }} >
                <div className="flex-grow">
                    <h2 className="font-lora text-2xl font-bold text-[#1C3A3A]">{personalizedTitle}</h2>
                    <p className="text-slate-500 mb-5">{userProfile?.onboardingCompleted ? "Based on your preferences." : "Suggestions based on the time of day."}</p>
                    <div className="-mx-6 px-4 flex gap-5 overflow-x-auto pb-4 snap-x snap-mandatory">
                        {recommendedPlaces.map((place, index) => (
                             <motion.div key={place.id} className="snap-center sm:snap-start w-4/5 sm:w-2/5 lg:w-1/3 flex-shrink-0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1, duration: 0.4 }}>
                                <PlaceCard place={place} />
                            </motion.div>
                        ))}
                    </div>
                </div>
                <div className="flex-shrink-0 mt-auto pt-4 text-center">
                     {aiError && <p className="text-red-500 text-sm mb-2">{aiError}</p>}
                    <button onClick={handleGetSuggestion} className="bg-gradient-to-br from-[#FF712F] to-[#ff8c56] text-white font-semibold px-8 py-3.5 rounded-full shadow-lg shadow-[#FF712F]/30 hover:shadow-xl hover:scale-105 transition-all duration-300">
                       ✨ I'm Feeling Lucky
                    </button>
                </div>
            </motion.div>
        );
    };

    return (
        <AnimatePresence mode="wait">
            <motion.div key={isAiLoading ? 'loading' : (suggestion ? 'suggestion' : 'default')} className="bg-white rounded-2xl p-6 border border-slate-200/80 min-h-[384px] flex flex-col" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }} >
                {isAiLoading ? <AILoadingState /> : (suggestion ? <AISuggestionState /> : <DefaultState />)}
            </motion.div>
        </AnimatePresence>
    );
};

const VibeButtons = () => {
  const navigate = useNavigate();
  return (
    <div>
      <h2 className="font-lora text-3xl font-bold text-[#1C3A3A] mb-5">Discover by Vibe</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {VIBES.map((vibe, index) => (
          <motion.button key={vibe.id} onClick={() => navigate(`/vibe/${vibe.id}`)} className="flex items-center gap-4 p-5 bg-white rounded-2xl border border-slate-200/80 text-left group transition-all duration-300 hover:border-[#1C3A3A]/30" whileHover={{ y: -6, boxShadow: "0 10px 20px -5px rgba(0,0,0,0.08)" }} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} >
            <div className="w-12 h-12 bg-[#FF712F]/20 rounded-xl flex items-center justify-center transition-colors duration-300 group-hover:bg-[#FF712F]/30">
                <VibeIcon type={vibe.icon} className="w-7 h-7 text-[#FF712F]" />
            </div>
            <span className="font-lora font-bold text-slate-800 text-lg">{vibe.name}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

const QuickActions = ({ onFilter, activeFilter }: { onFilter: (filter: string) => void, activeFilter: string | null }) => {
    const actions = [
        { id: 'social', label: 'Feeling Social', icon: 'Users' as VibeType },
        { id: 'wifi', label: 'Need WiFi', icon: 'Wifi' as VibeType },
        { id: 'new', label: 'Something New', icon: 'Wand2' as VibeType },
        { id: 'walking', label: 'Walking Distance', icon: 'Footprints' as VibeType },
    ];
    return (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {actions.map(action => (
                <button
                    key={action.id}
                    onClick={() => onFilter(action.id)}
                    className={`flex items-center justify-center gap-2.5 p-4 rounded-xl text-sm font-semibold transition-all duration-300 border-2 ${
                        activeFilter === action.id 
                        ? 'bg-[#1C3A3A] text-white border-transparent shadow-lg shadow-[#1C3A3A]/20'
                        : 'bg-white text-slate-700 border-slate-200/80 hover:border-[#1C3A3A]/50 hover:text-[#1C3A3A] hover:-translate-y-1'
                    }`}
                >
                    <VibeIcon type={action.icon} className="w-5 h-5" />
                    <span className="hidden sm:inline">{action.label}</span>
                </button>
            ))}
        </div>
    );
};

const FilteredResults = ({ places, title, onClear }: { places: Place[], title: string, onClear: () => void }) => {
    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="flex justify-between items-center mb-5">
                <h2 className="font-lora text-3xl font-bold text-[#1C3A3A]">{title}</h2>
                <button onClick={onClear} className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-[#1C3A3A] bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-full transition-colors">
                    <X className="w-4 h-4" />
                    Clear
                </button>
            </div>
            {places.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {places.map((place, index) => (
                        <motion.div
                            key={place.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                        >
                            <PlaceCard place={place} />
                        </motion.div>
                    ))}
                </div>
            ) : (
                <p className="text-center py-20 text-slate-500 bg-slate-50 rounded-2xl">No places found for this filter. Try another one!</p>
            )}
        </motion.div>
    );
};

const ChallengePlaceCard = ({ place }: { place: Place }) => {
    const navigate = useNavigate();
    return (
        <div 
            onClick={() => navigate(`/place/${place.id}`)}
            className="bg-white/60 p-3 rounded-xl border border-slate-200/70 hover:bg-white hover:border-slate-300 transition-all cursor-pointer group flex items-center gap-3"
        >
            <img src={place.imageUrl} alt={place.name} className="w-14 h-14 object-cover rounded-lg flex-shrink-0" />
            <div className="overflow-hidden">
                <p className="font-semibold text-slate-800 truncate text-sm">{place.name}</p>
                <p className="text-xs text-slate-500 truncate">{place.location.neighborhood}</p>
            </div>
        </div>
    );
};

const WeeklyChallenge = () => {
    const { userProfile, getPlaceById } = useAppContext();
    
    if (!userProfile?.currentChallenge) {
        return null;
    }
    
    const { currentChallenge } = userProfile;
    const recommendedPlaces = currentChallenge.relatedPlaceIds
        .map(id => getPlaceById(id))
        .filter((p): p is Place => p !== undefined);

    const challengeIcons: {[key: string]: VibeType} = {
        'new_neighborhood': 'MapPin',
        'small_talk': 'MessagesSquare',
        'study_spot': 'Coffee',
        'local_taste': 'UtensilsCrossed'
    };

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="bg-gradient-to-br from-amber-50 to-orange-100/70 p-6 rounded-2xl border border-amber-200/50 shadow-lg shadow-amber-500/5"
        >
            <div className="flex items-center gap-4 mb-3">
                <div className="w-10 h-10 bg-[#1C3A3A] rounded-xl flex items-center justify-center text-white">
                    <VibeIcon type="Target" className="w-6 h-6"/>
                </div>
                <div>
                    <h2 className="font-lora text-2xl font-bold text-[#1C3A3A]">This Week's Challenge</h2>
                </div>
            </div>
            
            <p className="font-semibold text-lg text-slate-800">{currentChallenge.title}</p>
            <p className="text-slate-600 mb-5 text-sm">{currentChallenge.description}</p>
            
            {recommendedPlaces.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {recommendedPlaces.map(place => (
                       <ChallengePlaceCard key={place.id} place={place} />
                    ))}
                </div>
            )}
        </motion.div>
    );
};


// --- Main Component ---

export default function HomePage() {
  const { places, isLoading, isAuthLoading, error, user, userProfile, bucketList, getPlaceById } = useAppContext();
  
  const [pageContext, setPageContext] = useState(() => getHomePageContext());
  const [weather, setWeather] = useState<Weather | null>(null);
  const [todaysEvent, setTodaysEvent] = useState<{place: Place, item: BucketListItem} | null>(null);

  useEffect(() => {
    const fetchWeather = async () => {
        const cacheKey = 'weather-San Francisco';
        // Try cache first
        try {
            const cachedData = localStorage.getItem(cacheKey);
            if(cachedData) {
                const { weather: cachedWeather, timestamp } = JSON.parse(cachedData);
                // Use cache if it's less than 15 minutes old (15 * 60 * 1000 ms)
                if (Date.now() - timestamp < 900000) {
                    setWeather(cachedWeather);
                    return; // Exit if fresh data is found in cache
                }
            }
        } catch(e) { console.error("Failed to read weather from cache", e); }

        // If no fresh data in cache, fetch new data
        const newWeather = await getWeather('San Francisco');
        setWeather(newWeather);

        // Update cache
        if (newWeather) {
            try {
                const cachePayload = { weather: newWeather, timestamp: Date.now() };
                localStorage.setItem(cacheKey, JSON.stringify(cachePayload));
            } catch(e) { console.error("Failed to write weather to cache", e); }
        }
    };

    fetchWeather();
    
    // This timer updates the time-of-day greeting periodically
    const timerId = setInterval(() => {
      setPageContext(currentContext => {
        const newContext = getHomePageContext();
        if (newContext.greeting !== currentContext.greeting) return newContext;
        return currentContext;
      });
    }, 1000 * 60 * 5); // Check every 5 minutes

    return () => clearInterval(timerId);
  }, []); 

  useEffect(() => {
    if (user && bucketList) {
        const todayStr = new Date().toISOString().split('T')[0];
        const scheduledEntry = Object.entries(bucketList).find(([, item]) => (item as BucketListItem).scheduledDate === todayStr);
        if (scheduledEntry) {
            const [placeId, item] = scheduledEntry;
            const place = getPlaceById(placeId);
            if (place) {
                setTodaysEvent({ place, item: item as BucketListItem });
            }
        } else {
             setTodaysEvent(null);
        }
    }
  }, [user, bucketList, getPlaceById]);

  const personalizedName = useMemo(() => {
    if (user && !user.isAnonymous && userProfile?.firstName) {
      return userProfile.firstName;
    }
    return null;
  }, [user, userProfile?.firstName]);

  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [filteredPlaces, setFilteredPlaces] = useState<Place[]>([]);
  const [filterTitle, setFilterTitle] = useState('');

  const handleFilter = (filterType: string) => {
    if (filterType === activeFilter) {
        clearFilter();
        return;
    }

    setActiveFilter(filterType);
    let results: Place[] = [];
    let title = '';

    switch (filterType) {
        case 'social':
            title = 'Great Spots to Socialize';
            results = places.filter(p => {
                const tags = ((p.tags?.vibeTags || []) + ',' + (p.tags?.bestFor || [])).toLowerCase();
                return tags.includes('social') || tags.includes('lively') || tags.includes('group') || tags.includes('bar') || tags.includes('music');
            });
            break;
        case 'wifi':
            title = 'Get Work Done';
            results = places.filter(p => {
                const category = p.category.toLowerCase();
                const tags = (p.tags?.vibeTags || []).join(' ').toLowerCase();
                return category.includes('study') || category.includes('coffee') || tags.includes('wifi') || tags.includes('work') || tags.includes('laptop');
            });
            break;
        case 'new':
            title = 'Something New For You';
            results = [...places].sort(() => 0.5 - Math.random()).slice(0, 6);
            break;
        case 'walking':
            title = 'A Short Walk Away';
            results = places.filter(p => {
                const walkTime = parseInt(p.location.walkFromEC, 10);
                return !isNaN(walkTime) && walkTime <= 15;
            });
            break;
    }
    setFilteredPlaces(results);
    setFilterTitle(title);
  }

  const clearFilter = () => {
    setActiveFilter(null);
    setFilteredPlaces([]);
    setFilterTitle('');
  }

  if (error) {
    return (
        <div className="text-center p-6 bg-red-50 border border-red-200 rounded-lg">
            <h3 className="font-bold text-red-800">Application Error</h3>
            <p className="text-red-700 mt-1">{error}</p>
        </div>
    );
  }

  const showLoadingSkeleton = isLoading || isAuthLoading;

  const DefaultContent = () => (
     <motion.div 
        key="default-content" 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }} 
        transition={{ duration: 0.3 }}
        className="space-y-12 lg:space-y-16"
    >
        {showLoadingSkeleton ? <Skeleton className="h-96 w-full rounded-2xl" /> : <ForYouNow context={pageContext} />}
        <VibeButtons />
    </motion.div>
  );
  
  const showChallenge = user && !user.isAnonymous && userProfile?.onboardingCompleted;

  return (
    <div className="space-y-10 lg:space-y-12">
      <DynamicGreeting 
          greeting={pageContext.greeting} 
          description={pageContext.description} 
          name={personalizedName} 
          weather={weather}
      />
      
      <QuickActions onFilter={handleFilter} activeFilter={activeFilter} />

      <AnimatePresence>
        {todaysEvent && <TodaysPlanCard todaysEvent={todaysEvent} />}
      </AnimatePresence>

      <AnimatePresence>
        {showChallenge && <WeeklyChallenge />}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {activeFilter ? (
            <FilteredResults key="filtered-results" places={filteredPlaces} title={filterTitle} onClear={clearFilter} />
        ) : (
            <DefaultContent />
        )}
      </AnimatePresence>
    </div>
  );
}