
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAppContext } from '../context/AppContext.tsx';
import { CalendarDays, MapPin, Clock, Users } from 'lucide-react';
import { Skeleton } from './common/Skeleton.tsx';
import VibeIcon from './common/Icons.tsx';

const EventCard = ({ event, place }: { event: any, place: any }) => {
    const navigate = useNavigate();
    const eventDate = new Date(event.dateTime);
    const formattedDate = eventDate.toLocaleDateString(undefined, { month: 'long', day: 'numeric' });
    const formattedTime = eventDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true });

    return (
        <motion.div
            onClick={() => navigate(`/event/${event.id}`)}
            className="bg-white rounded-2xl border border-slate-200/80 hover:border-[#1C3A3A]/30 transition-all duration-300 cursor-pointer group p-5 flex flex-col sm:flex-row gap-5"
            whileHover={{ y: -6, boxShadow: "0 10px 20px -5px rgba(0,0,0,0.08)" }}
        >
            <img src={place.imageUrl} alt={place.name} className="w-full sm:w-32 h-40 sm:h-32 object-cover rounded-xl" />
            <div className="flex-1 space-y-3">
                <div>
                    <p className="text-sm font-semibold text-[#FF712F]">{event.vibe}</p>
                    <h3 className="font-lora font-bold text-2xl text-slate-800 leading-tight group-hover:underline">{place.name}</h3>
                </div>
                <div className="text-sm text-slate-500 space-y-1.5">
                    <p className="flex items-center gap-2"><MapPin className="w-4 h-4" />{place.location.neighborhood}</p>
                    <p className="flex items-center gap-2"><Clock className="w-4 h-4" />{formattedDate} at {formattedTime}</p>
                </div>
                <p className="text-xs text-slate-400 italic pt-2 border-t border-slate-100">Created by {event.createdBy.firstName}</p>
            </div>
        </motion.div>
    );
};

export default function EventsPage() {
    const { events, getPlaceById, isAuthLoading, userProfile } = useAppContext();
    const navigate = useNavigate();

    if (isAuthLoading) {
        return (
            <div className="space-y-6">
                <Skeleton className="h-16 w-3/4 mb-4" />
                <Skeleton className="h-40" />
                <Skeleton className="h-40" />
                <Skeleton className="h-40" />
            </div>
        );
    }
    
    const sortedEvents = [...events].sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime());

    return (
        <div className="space-y-8">
            <div className="flex items-center gap-5 border-b border-slate-200/80 pb-6">
                <div className="w-20 h-20 bg-[#FF712F]/20 rounded-2xl flex items-center justify-center">
                    <CalendarDays className="w-10 h-10 text-[#FF712F]" />
                </div>
                <div>
                    <p className="text-sm font-semibold text-[#FF712F]">Community</p>
                    <h1 className="font-lora text-4xl lg:text-5xl font-bold text-[#1C3A3A] tracking-tight">Upcoming Events</h1>
                    <p className="text-slate-500 text-md mt-1">Events for students at {userProfile?.school || 'your school'}.</p>
                </div>
            </div>

            {sortedEvents.length > 0 ? (
                <div className="space-y-6">
                    {sortedEvents.map(event => {
                        const place = getPlaceById(event.placeId);
                        if (!place) return null;
                        return <EventCard key={event.id} event={event} place={place} />;
                    })}
                </div>
            ) : (
                <div className="text-center py-20 px-6 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                    <h3 className="font-lora text-2xl font-bold text-[#1C3A3A]">No Events Yet</h3>
                    <p className="text-slate-500 mt-2 mb-6 max-w-md mx-auto">It looks like no events have been planned. Why not be the first? Find a place and create an event!</p>
                    <button
                        onClick={() => navigate('/map')}
                        className="bg-[#1C3A3A] text-white font-semibold px-6 py-3 rounded-full hover:bg-opacity-90 transition-colors"
                    >
                        Explore Places
                    </button>
                </div>
            )}
        </div>
    );
}