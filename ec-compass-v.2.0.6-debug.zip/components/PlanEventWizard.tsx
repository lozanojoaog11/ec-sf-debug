
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Clock, Users, Shield, MessageSquare, MapPin, LoaderCircle } from 'lucide-react';
import { useAppContext } from '../context/AppContext.tsx';

interface PlanEventWizardProps {
  placeId: string;
  placeName: string;
  onClose: () => void;
  onEventCreated: (eventId: string) => void;
}

const StepIndicator = ({ current, total }: { current: number, total: number }) => (
    <div className="flex justify-center gap-2 mb-4">
        {Array.from({ length: total }).map((_, i) => (
            <div key={i} className={`w-2.5 h-2.5 rounded-full transition-colors ${i + 1 === current ? 'bg-[#1C3A3A]' : 'bg-slate-200'}`} />
        ))}
    </div>
);

const PlanEventWizard: React.FC<PlanEventWizardProps> = ({ placeId, placeName, onClose, onEventCreated }) => {
  const { createEvent } = useAppContext();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    date: '',
    time: '',
    groupPrivacy: 'school' as 'school' | 'class',
    maxParticipants: 5,
    vibe: '',
    meetingPoint: '',
    details: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      handleSubmit();
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'maxParticipants' ? parseInt(value) : value }));
  };
  
  const getToday = () => new Date().toISOString().split('T')[0];

  const handleSubmit = async () => {
    if (!formData.date || !formData.time || !formData.vibe) {
      setError("Please fill in all required fields.");
      return;
    }
    setIsLoading(true);
    setError('');
    
    const dateTime = new Date(`${formData.date}T${formData.time}`);

    try {
      const newEventId = await createEvent({
        placeId: placeId,
        dateTime: dateTime.toISOString(),
        groupPrivacy: formData.groupPrivacy,
        maxParticipants: formData.maxParticipants,
        vibe: formData.vibe,
        meetingPoint: formData.meetingPoint,
        details: formData.details
      });
      if (newEventId) {
        onEventCreated(newEventId);
      } else {
        throw new Error("Failed to create event. You might need to log in.");
      }
    } catch(err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="font-lora text-2xl font-bold text-[#1C3A3A] text-center">When do you want to go?</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="date" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Calendar className="w-4 h-4" /> Date</label>
                <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} min={getToday()} required className="w-full p-3 border border-slate-300 rounded-xl bg-white"/>
              </div>
              <div>
                <label htmlFor="time" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Clock className="w-4 h-4" /> Time</label>
                <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} required className="w-full p-3 border border-slate-300 rounded-xl bg-white"/>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <h3 className="font-lora text-2xl font-bold text-[#1C3A3A] text-center">Group Details</h3>
             <div className="space-y-4">
                <div>
                    <label htmlFor="groupPrivacy" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Shield className="w-4 h-4" /> Who can join?</label>
                    <select id="groupPrivacy" name="groupPrivacy" value={formData.groupPrivacy} onChange={handleChange} className="w-full p-3 border border-slate-300 rounded-xl bg-white">
                        <option value="school">All EC Students</option>
                        <option value="class">My Class Only</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="maxParticipants" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Users className="w-4 h-4" /> Max Participants ({formData.maxParticipants})</label>
                    <input type="range" id="maxParticipants" name="maxParticipants" min="2" max="10" value={formData.maxParticipants} onChange={handleChange} className="w-full"/>
                </div>
                 <div>
                    <label htmlFor="vibe" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><MessageSquare className="w-4 h-4" /> What's the vibe?</label>
                    <input type="text" id="vibe" name="vibe" value={formData.vibe} onChange={handleChange} placeholder="e.g., Study session, Social hangout, Photo walk" required className="w-full p-3 border border-slate-300 rounded-xl bg-white"/>
                </div>
             </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
             <h3 className="font-lora text-2xl font-bold text-[#1C3A3A] text-center">Meeting Details</h3>
             <div className="space-y-4">
                <div>
                    <label htmlFor="meetingPoint" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><MapPin className="w-4 h-4" /> Where exactly will you meet?</label>
                    <input type="text" id="meetingPoint" name="meetingPoint" value={formData.meetingPoint} onChange={handleChange} placeholder="e.g., At the main entrance" required className="w-full p-3 border border-slate-300 rounded-xl bg-white"/>
                </div>
                <div>
                    <label htmlFor="details" className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><MessageSquare className="w-4 h-4" /> How will people find you?</label>
                    <textarea id="details" name="details" value={formData.details} onChange={handleChange} placeholder="e.g., I'll be wearing a red jacket. Let's create a WhatsApp group!" rows={3} className="w-full p-3 border border-slate-300 rounded-xl bg-white"/>
                </div>
             </div>
          </div>
        );
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}>
      <motion.div
        initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="bg-slate-50 rounded-2xl p-6 w-full max-w-md relative shadow-2xl border border-slate-200"
      >
        <button onClick={onClose} className="absolute top-3 right-3 p-2 text-slate-400 hover:text-slate-700"><X className="w-5 h-5"/></button>
        <div className="text-center mb-4">
            <h2 className="font-lora text-3xl font-bold text-[#1C3A3A]">Plan a Visit</h2>
            <p className="text-slate-500">to {placeName}</p>
        </div>
        
        <StepIndicator current={step} total={3} />
        
        <form onSubmit={handleNext}>
          <div className="min-h-[250px] flex items-center">
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full">
                {renderStep()}
              </motion.div>
            </AnimatePresence>
          </div>

          {error && <p className="text-red-500 text-sm text-center my-2">{error}</p>}

          <div className="flex items-center gap-4 mt-6">
            {step > 1 && <button type="button" onClick={() => setStep(step - 1)} className="w-full text-center bg-slate-200 text-slate-700 font-semibold px-6 py-3 rounded-xl hover:bg-slate-300 transition-colors">Back</button>}
            <button type="submit" disabled={isLoading} className="w-full text-center bg-[#1C3A3A] text-white font-semibold px-6 py-3 rounded-xl hover:bg-opacity-90 transition-colors disabled:bg-slate-300">
                {isLoading ? <LoaderCircle className="w-6 h-6 animate-spin mx-auto"/> : (step === 3 ? 'Create Event' : 'Next')}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default PlanEventWizard;