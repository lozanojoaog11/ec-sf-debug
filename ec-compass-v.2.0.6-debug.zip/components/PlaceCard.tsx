
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Place } from '../types.ts';
import { Badge } from './common/Badge.tsx';
import VibeIcon from './common/Icons.tsx';
import SaveButton from './common/BucketListButton.tsx';

interface PlaceCardProps {
  place: Place;
  className?: string;
}

const PlaceCard = ({ place, className }: PlaceCardProps) => {
  const navigate = useNavigate();

  return (
    <motion.div
      className={`relative bg-white rounded-2xl overflow-hidden border border-slate-200/80 hover:border-[#1C3A3A]/30 transition-all duration-300 cursor-pointer group ${className}`}
      onClick={() => navigate(`/place/${place.id}`)}
      whileHover={{ y: -6, boxShadow: "0 10px 20px -5px rgba(0,0,0,0.08)" }}
      layout
    >
      <div className="absolute top-3 left-3 z-10">
        <SaveButton placeId={place.id} />
      </div>
      <div className="relative aspect-[4/3] overflow-hidden">
        <motion.img
          src={place.imageUrl}
          alt={place.name}
          className="w-full h-full object-cover transition-transform duration-500 ease-in-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
        <div className="absolute top-4 right-4">
          <Badge className="bg-white/20 text-white backdrop-blur-md shadow-sm border border-white/20">{place.category}</Badge>
        </div>
      </div>
      <div className="p-5">
        <h3 className="font-lora font-bold text-xl text-slate-800 leading-tight truncate">{place.name}</h3>
        <p className="text-slate-500 text-sm flex items-center gap-1.5 mt-1">
            <VibeIcon type="MapPin" className="w-4 h-4 text-slate-400" />
            {place.location.neighborhood}
        </p>
        <div className="flex flex-wrap gap-1.5 mt-3">
          {(place.tags.vibeTags || []).slice(0, 3).map(tag => (
            <Badge key={tag}>{tag.startsWith('#') ? tag : `#${tag}`}</Badge>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export default React.memo(PlaceCard);