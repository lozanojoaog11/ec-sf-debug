
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { getEventsForPlaceBySchool, getEventAttendees } from '../services/firebaseService.ts';
import { Event, EventAttendee, PublicUserProfile } from '../types.ts';
import { Skeleton } from './common/Skeleton.tsx';
import { Users, Calendar, Clock, UserCheck } from 'lucide-react';
import { useAppContext } from '../context/AppContext.tsx';

const AvatarStack = ({ attendees, max = 4 }: { attendees: PublicUserProfile[], max?: number }) => {
    const displayed = attendees.slice(0, max);
    const hiddenCount = attendees.length - displayed.length;

    return (
        <div className="flex items-center">
            <div className="flex -space-x-2">
                {displayed.map(p => (
                    <img key={p.uid} src={p.photoURL} alt={p.firstName} className="w-8 h-8 rounded-full object-cover border-2 border-white" />
                ))}
            </div>
            {hiddenCount > 0 && <span className="text-xs font-semibold text-slate-500 ml-3">+{hiddenCount} more</span>}
        </div>
    )
}


const EventCard = ({ event }: { event: Event }) => {
    const { user, userProfile, rsvpToEvent } = useAppContext();
    const [attendees, setAttendees] = useState<EventAttendee>({});
    const [isLoading, setIsLoading] = useState(true);

    const isAttending = user ? !!attendees[user.uid] : false;

    useEffect(() => {
        const fetchAttendees = async () => {
            setIsLoading(true);
            const data = await getEventAttendees(event.id);
            setAttendees(data);
            setIsLoading(false);
        };
        fetchAttendees();
    }, [event.id]);
    
    const handleRsvp = () => {
        if (!user || !userProfile) return;

        const currentU = user;
        const currentProfile = userProfile;
    
        rsvpToEvent(event.id, isAttending ? 'cant-go' : 'going');
        // Optimistic update
        setAttendees(prev => {
            const newAttendees = { ...prev };
            if (isAttending) {
                delete newAttendees[currentU.uid];
            } else {
                newAttendees[currentU.uid] = {
                    firstName: currentProfile.firstName || 'Student',
                    photoURL: currentU.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${currentProfile.firstName || 'EC'}`,
                    status: 'going'
                };
            }
            return newAttendees;
        });
    };
    
    const attendeesArray: PublicUserProfile[] = Object.entries(attendees).map(([uid, data]) => ({
        uid,
        firstName: data.firstName,
        photoURL: data.photoURL,
        country: '', // Not needed for display
        school: '', // Not needed for display
    }));

    const eventDate = new Date(event.dateTime);
    const formattedDate = eventDate.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
    const formattedTime = eventDate.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true });

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-5 rounded-2xl border border-slate-200/80 space-y-4"
        >
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-lg text-[#1C3A3A]">{event.vibe}</p>
                    <div className="flex items-center gap-4 text-sm text-slate-500 mt-1">
                        <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5"/> {formattedDate}</span>
                        <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5"/> {formattedTime}</span>
                    </div>
                </div>
                 <button 
                    onClick={handleRsvp}
                    disabled={!user || user.isAnonymous}
                    className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-full transition-colors ${
                        isAttending 
                        ? 'bg-teal-500 text-white hover:bg-teal-600'
                        : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                    }`}
                 >
                    <UserCheck className="w-4 h-4"/>
                    {isAttending ? "I'm Going!" : "Count me in!"}
                 </button>
            </div>
            {attendeesArray.length > 0 && <AvatarStack attendees={attendeesArray} />}
             <p className="text-xs text-slate-400 italic">Created by {event.createdBy.firstName}</p>
        </motion.div>
    );
};


const ActiveEvents: React.FC<{ placeId: string }> = ({ placeId }) => {
    const { userProfile } = useAppContext();
    const [events, setEvents] = useState<Event[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!userProfile?.school) {
            setIsLoading(false);
            return;
        }
        const fetchEvents = async () => {
            setIsLoading(true);
            const fetchedEvents = await getEventsForPlaceBySchool(placeId, userProfile.school);
            setEvents(fetchedEvents);
            setIsLoading(false);
        };
        fetchEvents();
    }, [placeId, userProfile?.school]);

    if (isLoading) {
        return <Skeleton className="h-32 w-full rounded-2xl" />;
    }

    if (events.length === 0) {
        return null;
    }

    return (
        <div>
            <h3 className="font-lora text-xl font-bold text-[#1C3A3A] mb-4">Upcoming Events Here</h3>
            <div className="space-y-4">
                <AnimatePresence>
                    {events.map(event => <EventCard key={event.id} event={event} />)}
                </AnimatePresence>
            </div>
        </div>
    )
};

export default ActiveEvents;