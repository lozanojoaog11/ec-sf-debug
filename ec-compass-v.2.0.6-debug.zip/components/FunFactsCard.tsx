import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import VibeIcon from './common/Icons.tsx';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface FunFactsCardProps {
  facts: string[];
}

const factVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 50 : -50,
    opacity: 0,
    scale: 0.9,
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
    scale: 1,
  },
  exit: (direction: number) => ({
    zIndex: 0,
    x: direction < 0 ? 50 : -50,
    opacity: 0,
    scale: 0.9,
  }),
};

const FunFactsCard: React.FC<FunFactsCardProps> = ({ facts }) => {
  const [[page, direction], setPage] = useState([0, 0]);

  if (!facts || facts.length === 0) {
    return null;
  }

  const paginate = (newDirection: number) => {
    const newIndex = (page + newDirection + facts.length) % facts.length;
    setPage([newIndex, newDirection]);
  };

  return (
    <div className="bg-yellow-50/70 border-l-4 border-yellow-400 p-6 rounded-r-xl relative overflow-hidden min-h-[160px] flex flex-col justify-center">
        <h3 className="font-lora text-2xl font-bold text-yellow-800 flex items-center gap-3 mb-3">
            <VibeIcon type="Lightbulb" className="w-6 h-6" />
            Did You Know?
        </h3>
        <div className="relative flex-grow flex items-center justify-center">
            <AnimatePresence initial={false} custom={direction}>
                <motion.p
                    key={page}
                    custom={direction}
                    variants={factVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{
                        x: { type: 'spring', stiffness: 300, damping: 30 },
                        opacity: { duration: 0.2 },
                        scale: { duration: 0.2 },
                    }}
                    className="text-yellow-900 leading-relaxed text-md text-center px-8"
                >
                    {facts[page]}
                </motion.p>
            </AnimatePresence>
        </div>
        
        {facts.length > 1 && (
            <div className="absolute bottom-4 right-4 flex items-center gap-2">
                <button 
                    onClick={() => paginate(-1)} 
                    className="p-2 rounded-full bg-black/5 hover:bg-black/10 transition-colors"
                    aria-label="Previous fact"
                >
                    <ChevronLeft className="w-5 h-5 text-yellow-800" />
                </button>
                <button 
                    onClick={() => paginate(1)} 
                    className="p-2 rounded-full bg-black/5 hover:bg-black/10 transition-colors"
                    aria-label="Next fact"
                >
                    <ChevronRight className="w-5 h-5 text-yellow-800" />
                </button>
            </div>
        )}
    </div>
  );
};

export default FunFactsCard;