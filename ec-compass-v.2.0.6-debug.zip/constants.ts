

import { VibeType } from './types.ts';

export const firebaseConfig = {
  apiKey: "AIzaSyAwda051Bz6YSd3XjylK9lP98E_7dqlCoY",
  authDomain: "ec-sf-navigator.firebaseapp.com",
  databaseURL: "https://ec-sf-navigator-default-rtdb.firebaseio.com",
  projectId: "ec-sf-navigator",
  storageBucket: "ec-sf-navigator.firebasestorage.app",
  messagingSenderId: "339185333126",
  appId: "1:339185333126:web:50b7c9ef582867adbaf207"
};

// IMPORTANT: Replace with the actual Firebase UID of the admin user(s).
// You can find a user's UID in the Firebase Console > Authentication > Users tab.
export const ADMIN_UIDS = ["REPLACE_WITH_YOUR_ADMIN_UID"];

interface Vibe {
    name: string;
    id: string;
    icon: VibeType;
    keywords: string[];
}

export const VIBES: Vibe[] = [
    { name: "Iconic Views", id: "views", icon: "Camera", keywords: ["view", "photo", "bridge", "vista", "skyline", "scenic"] },
    { name: "Free & Awesome", id: "free", icon: "Gift", keywords: ["free", "park", "walk", "hike", "public"] },
    { name: "Coffee & Study", id: "studyspot", icon: "Coffee", keywords: ["coffee", "study", "cafe", "work", "laptop", "bakery"] },
    { name: "Live Music", id: "livemusic", icon: "Music", keywords: ["music", "concert", "show", "venue", "band", "jazz"] },
    { name: "Late Night", id: "latenight", icon: "Moon", keywords: ["late", "night", "bar", "cocktail", "after-hours"] },
    { name: "Date Night", id: "romantic", icon: "Heart", keywords: ["date", "romantic", "couple", "intimate", "cozy", "special"] },
];

export interface BudgetOption {
    id: string;
    label: string;
    icon: VibeType;
    range: string[];
}

export const BUDGET_OPTIONS: BudgetOption[] = [
    { id: 'free', label: 'Free', icon: 'Gift', range: ['Free'] },
    { id: 'cheap', label: '$', icon: 'DollarSign', range: ['$'] },
    { id: 'moderate', label: '$$', icon: 'DollarSign', range: ['$$'] },
    { id: 'expensive', label: '$$$', icon: 'DollarSign', range: ['$$$', '$$$$'] },
];