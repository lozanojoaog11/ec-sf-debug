
import React, { createContext, useState, useEffect, useContext, ReactNode, useCallback, useMemo } from 'react';
import firebase from 'firebase/compat/app';
import { Place, User, UserProfile, BucketListItem, AppContextType, Event, PublicUserProfile, EventComment } from '../types.ts';
import * as firebaseService from '../services/firebaseService.ts';
import { signOut as firebaseSignOut } from '../services/firebaseService.ts';
import { generateNewChallenge } from '../services/challengeService.ts';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [places, setPlaces] = useState<Place[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [bucketList, setBucketList] = useState<{ [placeId: string]: BucketListItem }>({});
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    const fetchPlaces = async () => {
        setIsLoading(true);
        // Try loading from cache first
        try {
            const cachedData = localStorage.getItem('cachedPlaces');
            if (cachedData) {
                const { places: cachedPlaces, timestamp } = JSON.parse(cachedData);
                const cacheAge = Date.now() - timestamp;
                // Use cache if it's less than 6 hours old (6 * 60 * 60 * 1000 ms)
                if (cacheAge < 21600000) {
                    setPlaces(cachedPlaces);
                    setError(null);
                    setIsLoading(false);
                    return; // Stop here, we have fresh data from cache
                }
            }
        } catch (e) {
            console.error("Failed to read places from cache", e);
            // Clear corrupted cache
            localStorage.removeItem('cachedPlaces');
        }

        // If cache is old, invalid, or doesn't exist, fetch from Firebase
        try {
            const fetchedPlaces = await firebaseService.getPlaces();
            setPlaces(fetchedPlaces);
            // Update cache
            try {
                const cachePayload = {
                    places: fetchedPlaces,
                    timestamp: Date.now()
                };
                localStorage.setItem('cachedPlaces', JSON.stringify(cachePayload));
            } catch (e) {
                console.error("Failed to write places to cache", e);
            }
            setError(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    };

    fetchPlaces();
  }, []);

  useEffect(() => {
    let unsubscribeProfile = () => {};
    let unsubscribeBucketList = () => {};

    const authUnsubscribe = firebaseService.onAuthStateChanged(async (currentUser) => {
      // Unsubscribe from previous user's listeners before setting up new ones
      unsubscribeProfile();
      unsubscribeBucketList();

      setIsAuthLoading(true);
      setUser(currentUser);

      if (currentUser) {
        firebaseService.checkAdminStatus(currentUser).then(setIsAdmin);

        const profileRef = firebase.database().ref(`userProfiles/${currentUser.uid}`);
        const profileListener = profileRef.on('value', async (snapshot) => {
          const profile = snapshot.val() as UserProfile | null;
          if (profile) {
            setUserProfile(profile);
            
            // Sync public profile if onboarding is done but public profile might be missing
            if(profile.onboardingCompleted) {
                const publicProfileSnap = await firebase.database().ref(`publicUserProfiles/${currentUser.uid}`).once('value');
                if(!publicProfileSnap.exists()){
                     await firebaseService.createPublicUserProfile(currentUser, profile);
                }
            }
            // Fetch school-specific events
            if (profile.school) {
                firebaseService.getUpcomingEventsBySchool(profile.school).then(setEvents);
            }

          } else if (!currentUser.isAnonymous) {
            const defaultProfile: UserProfile = {
              englishLevel: null, userVibe: null, stayDuration: null,
              onboardingCompleted: false,
              firstName: currentUser.displayName?.split(' ')[0] || '',
              country: '', school: '', class: ''
            };
            await firebaseService.updateUserProfile(currentUser.uid, defaultProfile);
            setUserProfile(defaultProfile);
          } else {
            setUserProfile(null);
          }
        });
        unsubscribeProfile = () => profileRef.off('value', profileListener);

        if (!currentUser.isAnonymous) {
            const bucketListRef = firebase.database().ref(`userBucketLists/${currentUser.uid}`);
            const bucketListListener = bucketListRef.on('value', (snapshot) => {
                setBucketList(snapshot.val() || {});
            });
            unsubscribeBucketList = () => bucketListRef.off('value', bucketListListener);
        } else {
            // Anonymous users don't have bucket lists or events
            setBucketList({});
            setEvents([]);
            unsubscribeBucketList = () => {};
        }
        
      } else {
        setIsAdmin(false);
        setUserProfile(null);
        setBucketList({});
        setEvents([]);
        unsubscribeProfile = () => {};
        unsubscribeBucketList = () => {};
      }
      setIsAuthLoading(false);
    });

    return () => {
      authUnsubscribe();
      unsubscribeProfile();
      unsubscribeBucketList();
    };
  }, []);

  useEffect(() => {
    if (!user || user.isAnonymous || !userProfile || !userProfile.onboardingCompleted || places.length === 0) return;

    const shouldGenerate = !userProfile.currentChallenge || new Date(userProfile.currentChallenge.generatedAt) < new Date(new Date().setDate(new Date().getDate() - 7));
    if (shouldGenerate) {
        const newChallenge = generateNewChallenge(userProfile, places);
        if (newChallenge) {
            firebaseService.updateUserProfile(user.uid, { currentChallenge: newChallenge });
        }
    }
  }, [user, userProfile, places]);

  const getPlaceById = useCallback((id: string) => places.find(place => place.id === id), [places]);
  
  const addToBucketList = useCallback(async (placeId: string) => {
      if (!user || user.isAnonymous || !userProfile?.school) return;
      await firebaseService.addBucketListItem(user.uid, userProfile.school, placeId);
  }, [user, userProfile]);
  
  const removeFromBucketList = useCallback(async (placeId: string) => {
      if (!user || user.isAnonymous || !userProfile?.school) return;
      await firebaseService.removeBucketListItem(user.uid, userProfile.school, placeId);
  }, [user, userProfile]);

  const updateBucketListItem = useCallback(async (placeId: string, data: Partial<BucketListItem>) => {
    if (!user || user.isAnonymous || !userProfile?.school) return;
    await firebaseService.updateBucketListItem(user.uid, placeId, data);
    // If user marks as visited, they are no longer "wanting to go".
    if (data.status === 'been-there') {
        await firebaseService.syncPlaceInterest(user.uid, userProfile.school, placeId, false);
    }
  }, [user, userProfile]);

  const createEvent = useCallback(async (eventData: Omit<Event, 'id' | 'createdAt' | 'createdBy' | 'schoolId'>): Promise<string | undefined> => {
    if (!user || user.isAnonymous || !userProfile?.school || !userProfile?.firstName) return;
    
    const newEvent: Event = {
      ...eventData,
      id: '', // Will be set by Firebase
      schoolId: userProfile.school,
      createdBy: {
        uid: user.uid,
        firstName: userProfile.firstName,
        photoURL: user.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${userProfile.firstName || 'EC'}`
      },
      createdAt: new Date().toISOString()
    };
    
    const newEventId = await firebaseService.createEvent(newEvent);
    
    // Automatically RSVP the creator to their own event
    const publicProfile: PublicUserProfile = {
        uid: user.uid,
        firstName: userProfile.firstName,
        country: userProfile.country || 'Unknown',
        school: userProfile.school,
        class: userProfile.class,
        photoURL: newEvent.createdBy.photoURL,
    }
    await firebaseService.rsvpToEvent(newEventId, publicProfile, 'going');
    // Refresh events list
    if (userProfile.school) {
        firebaseService.getUpcomingEventsBySchool(userProfile.school).then(setEvents);
    }
    
    return newEventId;
  }, [user, userProfile]);

  const rsvpToEvent = useCallback(async (eventId: string, status: 'going' | 'cant-go') => {
    if (!user || user.isAnonymous || !userProfile?.school || !userProfile?.firstName) return;
    const publicProfile: PublicUserProfile = {
        uid: user.uid,
        firstName: userProfile.firstName,
        country: userProfile.country || 'Unknown',
        school: userProfile.school,
        class: userProfile.class,
        photoURL: user.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${userProfile.firstName || 'EC'}`,
    }
    await firebaseService.rsvpToEvent(eventId, publicProfile, status);
  }, [user, userProfile]);
  
  const addEventComment = useCallback(async (eventId: string, commentText: string) => {
    if (!user || user.isAnonymous || !userProfile?.firstName) return;
    
    const comment: Omit<EventComment, 'id'> = {
        text: commentText,
        createdAt: new Date().toISOString(),
        createdBy: {
            uid: user.uid,
            firstName: userProfile.firstName,
            photoURL: user.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${userProfile.firstName || 'EC'}`
        }
    };
    await firebaseService.addEventComment(eventId, comment);
  }, [user, userProfile]);

  const signOut = useCallback(async () => await firebaseSignOut(), []);

  const value: AppContextType = useMemo(() => ({
      places, isLoading, error, isAuthLoading, user, isAdmin, userProfile,
      bucketList, events, getPlaceById, addToBucketList, removeFromBucketList,
      updateBucketListItem, signOut, createEvent, rsvpToEvent, addEventComment
  }), [
      places, isLoading, error, isAuthLoading, user, isAdmin, userProfile,
      bucketList, events, getPlaceById, addToBucketList, removeFromBucketList,
      updateBucketListItem, signOut, createEvent, rsvpToEvent, addEventComment
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) throw new Error('useAppContext must be used within an AppProvider');
  return context;
};