
import { Weather } from '../types.ts';
import { getRealtimeWeather } from './geminiService.ts';

// This service now uses Gemini with Google Search grounding to provide real-time weather.

const getFallbackWeather = (): Weather => {
    // A safe fallback in case the API fails
    return {
        temp: 16,
        condition: 'Cloudy',
        icon: 'Cloud',
    };
};

export const getWeather = async (city: string = 'San Francisco'): Promise<Weather> => {
  console.log(`Fetching real-time weather for ${city} using Gemini...`);
    
    try {
        const realTimeWeather = await getRealtimeWeather(city);
        if (realTimeWeather) {
            return realTimeWeather;
        }
        console.warn("Could not fetch real-time weather, using fallback.");
        return getFallbackWeather();
    } catch (error) {
        console.error("Error in getWeather:", error);
        return getFallbackWeather();
    }
};