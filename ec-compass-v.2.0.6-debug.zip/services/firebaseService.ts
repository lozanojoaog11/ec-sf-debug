
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/database';
import { firebaseConfig, ADMIN_UIDS } from '../constants.ts';
import { Place, Image, UserProfile, BucketListItem, PublicUserProfile, Event, EventAttendee, EventComment } from '../types.ts';

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const database = firebase.database();

export const onAuthStateChanged = (callback: (user: firebase.User | null) => void) => {
    return auth.onAuthStateChanged(callback);
};

export const signInAnonymously = () => {
    return auth.signInAnonymously();
};

export const signOut = () => {
    return auth.signOut();
};

export const createUserWithEmail = (email: string, pass: string) => {
    return auth.createUserWithEmailAndPassword(email, pass);
}

export const signInWithEmail = (email: string, pass: string) => {
    return auth.signInWithEmailAndPassword(email, pass);
}

export const signInWithGoogle = () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    return auth.signInWithPopup(provider);
};

// --- Profile Management ---
export const getUserProfile = async (userId: string): Promise<UserProfile | null> => {
    const profileRef = database.ref(`userProfiles/${userId}`);
    const snapshot = await profileRef.once('value');
    return snapshot.val();
};

export const updateUserProfile = async (userId: string, profileData: Partial<UserProfile>): Promise<void> => {
    const profileRef = database.ref(`userProfiles/${userId}`);
    await profileRef.update(profileData);
};

export const createPublicUserProfile = async (user: firebase.User, profileData: Partial<UserProfile>): Promise<void> => {
    const publicProfileRef = database.ref(`publicUserProfiles/${user.uid}`);
    const publicProfile: PublicUserProfile = {
        uid: user.uid,
        firstName: profileData.firstName || 'Student',
        country: profileData.country || 'Unknown',
        school: profileData.school || 'EC English',
        class: profileData.class || 'N/A',
        photoURL: user.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${profileData.firstName || 'EC'}`,
    };
    await publicProfileRef.set(publicProfile);
};

// --- Bucket List & Social Sync ---
export const updateBucketListItem = async (userId: string, placeId: string, data: Partial<BucketListItem> | null): Promise<void> => {
    const itemRef = database.ref(`userBucketLists/${userId}/${placeId}`);
    if (data === null) {
      await itemRef.remove();
    } else {
      await itemRef.update(data);
    }
};

export const syncPlaceInterest = async (userId: string, schoolId: string, placeId: string, isInterested: boolean): Promise<void> => {
    if (!schoolId) {
        console.warn("Cannot sync place interest without a school ID.");
        return;
    }
    const interestRef = database.ref(`placeInterestBySchool/${encodeURIComponent(schoolId)}/${placeId}/${userId}`);
    if (isInterested) {
        await interestRef.set(true);
    } else {
        await interestRef.remove();
    }
};

export const addBucketListItem = async (userId: string, schoolId: string, placeId: string): Promise<void> => {
    const itemRef = database.ref(`userBucketLists/${userId}/${placeId}`);
    const newItem: BucketListItem = {
        status: 'want-to-go',
        addedAt: new Date().toISOString(),
        scheduledDate: null,
    };
    await itemRef.set(newItem);
    await syncPlaceInterest(userId, schoolId, placeId, true);
};

export const removeBucketListItem = async (userId: string, schoolId: string, placeId: string): Promise<void> => {
    const itemRef = database.ref(`userBucketLists/${userId}/${placeId}`);
    await itemRef.remove();
    await syncPlaceInterest(userId, schoolId, placeId, false);
};

// --- Social Feature Data Fetching ---
export const getInterestedUserIdsBySchool = async (placeId: string, schoolId: string): Promise<string[]> => {
    if (!schoolId) return [];
    const interestRef = database.ref(`placeInterestBySchool/${encodeURIComponent(schoolId)}/${placeId}`);
    const snapshot = await interestRef.once('value');
    if (snapshot.exists()) {
        return Object.keys(snapshot.val());
    }
    return [];
};

export const getPublicUserProfiles = async (userIds: string[]): Promise<PublicUserProfile[]> => {
    const profiles: PublicUserProfile[] = [];
    if (userIds.length === 0) return profiles;
    
    const promises = userIds.map(uid => 
        database.ref(`publicUserProfiles/${uid}`).once('value')
    );
    const snapshots = await Promise.all(promises);
    snapshots.forEach(snapshot => {
        if (snapshot.exists()) {
            profiles.push(snapshot.val());
        }
    });
    return profiles;
};


// --- Event Management ---
export const createEvent = async (eventData: Event): Promise<string> => {
    const eventRef = database.ref('events').push();
    const newId = eventRef.key;
    if (!newId) throw new Error("Could not create new event ID.");
    
    eventData.id = newId;
    await eventRef.set(eventData);
    return newId;
};

export const getUpcomingEventsBySchool = async (schoolId: string): Promise<Event[]> => {
    const eventsRef = database.ref('events');
    const now = new Date().toISOString();
    const snapshot = await eventsRef
        .orderByChild('schoolId')
        .equalTo(schoolId)
        .once('value');

    const events: Event[] = [];
    if (snapshot.exists()) {
        snapshot.forEach(childSnapshot => {
            const event = childSnapshot.val();
            if (event.dateTime > now) {
                events.push(event);
            }
        });
    }
    return events.sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime());
};

export const getEventById = async (eventId: string): Promise<Event | null> => {
    const eventRef = database.ref(`events/${eventId}`);
    const snapshot = await eventRef.once('value');
    return snapshot.val();
}

export const getEventsForPlaceBySchool = async (placeId: string, schoolId: string): Promise<Event[]> => {
    const eventsRef = database.ref('events');
    const now = new Date().toISOString();
    const snapshot = await eventsRef
        .orderByChild('schoolId')
        .equalTo(schoolId)
        .once('value');

    const events: Event[] = [];
    if (snapshot.exists()) {
        snapshot.forEach(childSnapshot => {
            const event = childSnapshot.val();
            // Filter by placeId and ensure event is not in the past
            if (event.placeId === placeId && event.dateTime > now) {
                events.push(event);
            }
        });
    }
    return events.sort((a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime());
};

export const rsvpToEvent = async (eventId: string, user: PublicUserProfile, status: 'going' | 'cant-go'): Promise<void> => {
    const rsvpRef = database.ref(`eventAttendees/${eventId}/${user.uid}`);
    if (status === 'going') {
        await rsvpRef.set({
            firstName: user.firstName,
            photoURL: user.photoURL,
            status: 'going',
        });
    } else {
        await rsvpRef.remove();
    }
};

export const getEventAttendees = async (eventId: string): Promise<EventAttendee> => {
    const attendeesRef = database.ref(`eventAttendees/${eventId}`);
    const snapshot = await attendeesRef.once('value');
    return snapshot.val() || {};
};

// --- Event Comments ---
export const addEventComment = async (eventId: string, comment: Omit<EventComment, 'id'>): Promise<void> => {
    const commentRef = database.ref(`eventComments/${eventId}`).push();
    const newId = commentRef.key;
    if (!newId) throw new Error("Could not create comment ID.");

    const newComment: EventComment = { ...comment, id: newId };
    await commentRef.set(newComment);
};

export const getEventCommentsStream = (eventId: string, callback: (comments: EventComment[]) => void): () => void => {
    const commentsRef = database.ref(`eventComments/${eventId}`).orderByChild('createdAt');
    const listener = commentsRef.on('value', (snapshot) => {
        const comments: EventComment[] = [];
        if (snapshot.exists()) {
            snapshot.forEach(childSnapshot => {
                comments.push(childSnapshot.val());
            });
        }
        callback(comments);
    });

    // Return the unsubscribe function
    return () => commentsRef.off('value', listener);
};


// --- Admin & Place Data ---
export const checkAdminStatus = async (user: firebase.User): Promise<boolean> => {
    if (!user) return false;
    if (ADMIN_UIDS.includes(user.uid)) return true;
    
    const adminRef = database.ref(`admins/${user.uid}`);
    const snapshot = await adminRef.once('value');
    return snapshot.exists();
};

const neighborhoodCoordinates: { [key: string]: { lat: number, lng: number } } = {
    'Mission': { lat: 37.76, lng: -122.42 }, 'Embarcadero': { lat: 37.795, lng: -122.395 }, 'Castro': { lat: 37.762, lng: -122.435 }, 'Presidio': { lat: 37.798, lng: -122.47 }, 'SoMa': { lat: 37.778, lng: -122.408 }, 'Outer Sunset': { lat: 37.755, lng: -122.50 }, 'Inner Sunset': { lat: 37.76, lng: -122.465 }, 'Chinatown': { lat: 37.795, lng: -122.407 }, 'North Beach': { lat: 37.805, lng: -122.41 }, 'Alamo Square': { lat: 37.776, lng: -122.435 }, 'Hayes Valley': { lat: 37.776, lng: -122.425 }, 'Nob Hill': { lat: 37.792, lng: -122.417 }, 'Russian Hill': { lat: 37.80, lng: -122.42 }, 'Marina': { lat: 37.803, lng: -122.44 }, 'Fillmore': { lat: 37.785, lng: -122.434 }, 'Civic Center': { lat: 37.779, lng: -122.419 }, 'Tenderloin': { lat: 37.784, lng: -122.414 }, 'Telegraph Hill': { lat: 37.802, lng: -122.405 }, 'Golden Gate Park': { lat: 37.769, lng: -122.486 }, 'Between Richmond and Sunset': { lat: 37.769, lng: -122.486 }, 'Lincoln Park': { lat: 37.78, lng: -122.50 }, 'Potrero Hill': { lat: 37.76, lng: -122.40 }, 'Mission Bay': { lat: 37.77, lng: -122.39 }, 'Cow Hollow': { lat: 37.795, lng: -122.44 }, 'Jackson Square': { lat: 37.797, lng: -122.40 }, 'Marin Headlands': { lat: 37.83, lng: -122.48 }, 'Dogpatch': { lat: 37.76, lng: -122.39 }, 'Lower Haight': { lat: 37.77, lng: -122.43 }, 'Richmond District': { lat: 37.778, lng: -122.47 }, 'North Beach/Chinatown': { lat: 37.798, lng: -122.408 }, 'Mission/Potrero': { lat: 37.76, lng: -122.408 }
};

export const getPlaces = async (): Promise<Place[]> => {
  try {
    const rootRef = database.ref('/');
    const snapshot = await rootRef.once('value');

    if (!snapshot.exists()) return [];

    const rootData = snapshot.val();
    const placesData = (rootData.places && typeof rootData.places === 'object') ? rootData.places : rootData;
    
    const placesArray: Place[] = Object.values(placesData)
      .filter((item: any): item is Place => item && typeof item === 'object' && 'id' in item && 'name' in item)
      .map((place: any): Place => {
        let coords = place.location?.coordinates;
        
        if (!coords || typeof coords.lat !== 'number' || typeof coords.lng !== 'number') {
            const baseCoords = neighborhoodCoordinates[place.location.neighborhood];
            coords = baseCoords 
                ? { lat: baseCoords.lat + (Math.random() - 0.5) * 0.005, lng: baseCoords.lng + (Math.random() - 0.5) * 0.005 }
                : { lat: 37.7749, lng: -122.4194 };
        }

        let processedImages: Image[] = [];
        if (place.images && typeof place.images === 'object') {
          processedImages = Object.values(place.images)
            .filter((img: any): img is Image => img && typeof img.url === 'string' && typeof img.thumb === 'string')
            .map((img: any) => ({ url: img.url, thumb: img.thumb, author: img.author || 'Unknown', source: img.source || 'Unknown' }));
        }

        if (processedImages.length === 0 && place.imageUrl && typeof place.imageUrl === 'string') {
          processedImages.push({ url: place.imageUrl, thumb: place.imageUrl, author: 'N/A', source: 'N/A' });
        }
        
        if (processedImages.length === 0) {
            processedImages.push({ url: `https://picsum.photos/seed/${place.id}/800/600`, thumb: `https://picsum.photos/seed/${place.id}/400/300`, author: 'Placeholder', source: 'Picsum' });
        }
        
        return {
            ...place,
            location: { ...place.location, coordinates: coords },
            images: processedImages,
            imageUrl: processedImages[0].thumb, 
        };
    });
    return placesArray;
  } catch (error) {
    console.error("Firebase Realtime Database Error:", error);
    if ((error as any).code === 'PERMISSION_DENIED') {
      throw new Error("Permission denied. You must be logged in to view places.");
    }
    throw new Error("Could not fetch places data from Firebase.");
  }
};

export const addPlace = async (placeData: Omit<Place, 'id'>): Promise<string> => {
    const newPlaceRef = database.ref('places').push();
    const newId = newPlaceRef.key;
    if (!newId) throw new Error("Could not create a new ID for the place.");
    const newPlace: Place = { ...placeData, id: newId };
    await newPlaceRef.set(newPlace);
    return newId;
};