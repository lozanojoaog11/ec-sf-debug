
import { GoogleGenAI, Type } from "@google/genai";
import { Place, ContextualSuggestion, WalkTour, PlaceInsights, Weather, WeatherCondition } from '../types.ts';

let ai: GoogleGenAI | null = null;

// Safe initialization.
// This relies on the execution environment providing process.env.API_KEY.
// In a standard browser environment without a build step, this will not be present.
try {
  // Use a check to prevent ReferenceError if 'process' is not defined.
  if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  } else {
    console.warn("Gemini API key not found. AI features will be disabled. Make sure API_KEY is set in your environment.");
  }
} catch (error) {
  console.error("Could not initialize Gemini AI Client:", error);
}


const suggestionSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A catchy, engaging title for the recommendation card (e.g., '🍻 HAPPY HOUR IN 30?')." },
        description: { type: Type.STRING, description: "A short, encouraging sentence explaining why this is a good idea right now." },
        recommendedPlaceIds: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "An array of IDs of 2-3 recommended places that fit the suggestion."
        }
    },
    required: ["title", "description", "recommendedPlaceIds"]
};

const walkTourSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A fun name for the walking tour (e.g., 'North Beach Bites & Views')." },
        steps: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    placeId: { type: Type.STRING, description: "The ID of the place for this step." },
                    instruction: { type: Type.STRING, description: "A short, simple instruction for this step of the tour (e.g., 'Start with a coffee at...')." }
                },
                required: ["placeId", "instruction"]
            },
            description: "An array of 2-3 steps for the walking tour."
        }
    },
    required: ["title", "steps"]
};

const insightsSchema = {
    type: Type.OBJECT,
    properties: {
        englishComfort: { 
            type: Type.INTEGER, 
            description: "On a scale of 1 (very difficult) to 5 (very easy), how comfortable is it for a non-native English speaker to communicate here? Consider the complexity of interactions and staff patience."
        },
        socialLevel: {
            type: Type.STRING,
            description: "Describe the social energy. Choose one: 'Quiet', 'Moderate', 'Lively', 'Very Social'."
        },
        bestFor: {
            type: Type.STRING,
            description: "Is this place better for individuals or groups? Choose one: 'Solo', 'Group', 'Mixed'."
        }
    },
    required: ["englishComfort", "socialLevel", "bestFor"]
};

export const getContextualSuggestion = async (places: Place[]): Promise<ContextualSuggestion | null> => {
    if (!ai) {
        console.warn("Gemini AI client not initialized. Cannot get suggestion.");
        return null;
    }

    const now = new Date();
    const dayOfWeek = now.toLocaleString('en-US', { weekday: 'long' });
    const time = now.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });

    const placeSummaries = places.map(p => ({
        id: p.id,
        name: p.name,
        category: p.category,
        tags: [...(p.tags.vibeTags || []), ...(p.tags.bestFor || [])].join(', ')
    }));

    const prompt = `
        You are "Compass", a knowledgeable and friendly local guide for international students in San Francisco.
        Your tone is encouraging, insightful, and slightly "insider."
        
        The current time is ${time} on a ${dayOfWeek}.

        Based on this context, generate a single, highly relevant suggestion for what a student could do right now.
        Your suggestion must have a catchy title and a short, inviting description.
        Recommend 2-3 places from the provided list that fit your suggestion.
        Do not recommend places that would be closed or inappropriate for this time (e.g., don't suggest a brunch spot at 10 PM).

        Here is the list of available places:
        ${JSON.stringify(placeSummaries, null, 2)}
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: suggestionSchema
            }
        });
        
        const jsonText = response.text.trim();
        try {
            const suggestion = JSON.parse(jsonText) as ContextualSuggestion;
            // Validate that the recommended IDs actually exist
            suggestion.recommendedPlaceIds = suggestion.recommendedPlaceIds.filter(id => places.some(p => p.id === id));
            if (suggestion.recommendedPlaceIds.length === 0) {
                console.warn("Gemini recommended place IDs that don't exist in the provided list.");
                return null;
            }
            return suggestion;
        } catch (parseError) {
             console.error("Gemini API did not return valid JSON for suggestion:", jsonText, parseError);
             return null;
        }

    } catch (error) {
        console.error("Error calling Gemini API for suggestions:", error);
        return null;
    }
};


export const generateWalkTour = async (places: Place[], neighborhood: string, duration: string): Promise<WalkTour | null> => {
    if (!ai) {
        console.warn("Gemini AI client not initialized. Cannot generate tour.");
        return null;
    }

    const relevantPlaces = places
        .filter(p => p.location.neighborhood === neighborhood)
        .map(p => ({ id: p.id, name: p.name, category: p.category, description: p.details.description }));

    if (relevantPlaces.length < 2) {
        console.log("Not enough places in the selected neighborhood to generate a tour.");
        return null; // Not enough places to make a tour
    }

    const prompt = `
        You are "Compass", a creative and efficient tour guide for international students in San Francisco.

        Create a short, logical walking tour in the "${neighborhood}" neighborhood that takes about ${duration}.
        The tour should connect 2-3 interesting and nearby places from the list provided below.
        Give the tour a fun, catchy title.
        For each step, provide the place ID and a short, simple instruction for what to do there.

        Here are the available places in this neighborhood:
        ${JSON.stringify(relevantPlaces, null, 2)}
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: walkTourSchema
            }
        });

        const jsonText = response.text.trim();
        try {
            const tour = JSON.parse(jsonText) as WalkTour;
            // Validate that the tour steps are valid
            tour.steps = tour.steps.filter(step => places.some(p => p.id === step.placeId));
            if (tour.steps.length < 2) {
                console.warn("Gemini generated a tour with invalid or too few steps.");
                return null;
            }
            return tour;
        } catch (parseError) {
             console.error("Gemini API did not return valid JSON for walk tour:", jsonText, parseError);
             return null;
        }

    } catch (error) {
        console.error("Error calling Gemini API for walk tour:", error);
        return null;
    }
};

export const generatePlaceInsights = async (
    englishCorner: Place['englishCorner']
): Promise<PlaceInsights | null> => {
    if (!ai) {
        console.warn("Gemini AI client not initialized. Cannot generate insights.");
        return null;
    }

    const prompt = `
        You are a data analyst for a city guide app for international students.
        Your task is to analyze the provided information about a place in San Francisco and generate three specific scores.
        Base your analysis ONLY on the provided "Cultural Context" and "Conversation Starters".

        - englishComfort: On a scale of 1 (very difficult, complex interactions) to 5 (very easy, simple ordering, patient staff), rate the location for a non-native English speaker. A quiet library is a 5. A loud, fast-paced bar is a 2. A museum is a 4.
        - socialLevel: Describe the typical social energy. Is it a quiet place for focus, a place for calm conversation, a lively hub, or a party atmosphere? Choose one: 'Quiet', 'Moderate', 'Lively', 'Very Social'.
        - bestFor: Is this a good spot to go alone, with a group of friends, or both? Choose one: 'Solo', 'Group', 'Mixed'.

        Here is the information for the location:
        - Cultural Context: "${englishCorner.culturalContext}"
        - Conversation Starters: "${englishCorner.conversationStarters.join(', ')}"

        Return your analysis in JSON format.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: insightsSchema,
                temperature: 0.2 // Lower temperature for more predictable, analytical output
            }
        });

        const jsonText = response.text.trim();
        try {
            const insights = JSON.parse(jsonText) as PlaceInsights;
            // Basic validation
            if (insights.englishComfort < 1 || insights.englishComfort > 5) {
                console.warn("Gemini returned an invalid 'englishComfort' score.");
                insights.englishComfort = 3; // Default to a moderate score
            }
            return insights;
        } catch (parseError) {
             console.error("Gemini API did not return valid JSON for insights:", jsonText, parseError);
             return null;
        }

    } catch (error) {
        console.error("Error calling Gemini API for insights:", error);
        return null;
    }
};

export const getRealtimeWeather = async (city: string): Promise<Weather | null> => {
    if (!ai) {
        console.warn("Gemini AI client not initialized. Cannot get weather.");
        return null;
    }

    const prompt = `
        You are a weather API. For the city "${city}", provide the current temperature in Celsius and a brief, one-word weather condition.
        Respond ONLY in the format: "Temp: [number], Condition: [word]".
        Example: "Temp: 15, Condition: Foggy".
        Do not add any other text, units, or explanation. The condition should be a single word like Sunny, Cloudy, Foggy, Rainy, Hazy, Clear.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
                temperature: 0, // We want deterministic output
            },
        });

        const text = response.text.trim();
        
        const tempMatch = text.match(/Temp: (\d+)/);
        const conditionMatch = text.match(/Condition: (\w+)/);

        if (!tempMatch || !conditionMatch) {
            console.error("Gemini weather response was not in the expected format:", text);
            return null;
        }

        const temp = parseInt(tempMatch[1], 10);
        const conditionStr = conditionMatch[1].toLowerCase();
        
        let condition: WeatherCondition;
        let icon: Weather['icon'];

        if (conditionStr.includes('sun') || conditionStr.includes('clear')) {
            condition = 'Sunny';
            icon = 'Sun';
        } else if (conditionStr.includes('cloud')) {
            condition = 'Cloudy';
            icon = 'Cloud';
        } else if (conditionStr.includes('rain') || conditionStr.includes('drizzle') || conditionStr.includes('shower')) {
            condition = 'Rainy';
            icon = 'CloudRain';
        } else if (conditionStr.includes('fog') || conditionStr.includes('mist') || conditionStr.includes('haze')) {
            condition = 'Foggy';
            icon = 'Wind';
        } else {
            // Fallback for unknown conditions
            condition = 'Cloudy';
            icon = 'Cloud';
        }

        return { temp, condition, icon };

    } catch (error) {
        console.error("Error calling Gemini API for weather:", error);
        return null;
    }
};