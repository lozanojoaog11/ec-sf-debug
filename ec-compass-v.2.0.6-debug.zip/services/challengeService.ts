
import { UserProfile, Place, Challenge } from '../types.ts';

interface ChallengeTemplate {
    id: Challenge['id'];
    title: string;
    description: string;
    isMatch: (place: Place, userProfile: UserProfile) => boolean;
    isApplicable: (userProfile: UserProfile) => boolean;
}

const CHALLENGE_TEMPLATES: ChallengeTemplate[] = [
    {
        id: 'new_neighborhood',
        title: 'Explore a New Neighborhood',
        description: 'Venture beyond the usual spots and discover the unique vibe of a different part of the city.',
        isApplicable: (profile) => profile.userVibe === 'explorer' || profile.stayDuration !== 'short',
        isMatch: (place, profile) => {
            // Simple logic: recommend neighborhoods that are not the most common ones.
            const commonNeighborhoods = ['mission', 'soma', 'embarcadero', 'north beach'];
            return !commonNeighborhoods.some(n => place.location.neighborhood.toLowerCase().includes(n));
        },
    },
    {
        id: 'small_talk',
        title: 'Practice Your Small Talk',
        description: 'Step into a friendly, social space and strike up a conversation. You can do it!',
        isApplicable: (profile) => profile.englishLevel !== 'starting',
        isMatch: (place, profile) => {
            const tags = [...(place.tags.vibeTags || []), ...(place.tags.bestFor || [])].join(' ').toLowerCase();
            return tags.includes('social') || tags.includes('lively') || tags.includes('bar') || tags.includes('friendly');
        },
    },
    {
        id: 'study_spot',
        title: 'Find Your Perfect Study Spot',
        description: 'Discover a new go-to place for quiet focus, great coffee, and reliable WiFi.',
        isApplicable: (profile) => profile.userVibe === 'learner' || profile.stayDuration !== 'short',
        isMatch: (place, profile) => {
            const searchableText = (place.category + ' ' + (place.tags.vibeTags || []).join(' ')).toLowerCase();
            return searchableText.includes('study') || searchableText.includes('coffee') || searchableText.includes('cafe') || searchableText.includes('library') || searchableText.includes('quiet');
        },
    },
    {
        id: 'local_taste',
        title: 'Taste Something Local',
        description: 'Try a dish or snack that\'s quintessentially San Franciscan, from sourdough to Mission-style burritos.',
        isApplicable: (profile) => profile.userVibe === 'explorer' || profile.englishLevel !== 'starting',
        isMatch: (place, profile) => {
            const searchableText = (place.category + ' ' + (place.tags.vibeTags || []).join(' ')).toLowerCase();
            return searchableText.includes('food') || searchableText.includes('restaurant') || searchableText.includes('bakery') || searchableText.includes('local') || searchableText.includes('burrito') || searchableText.includes('sourdough');
        },
    },
];

export const generateNewChallenge = (userProfile: UserProfile, places: Place[]): Challenge | null => {
    // Filter challenges that are applicable to the user's profile
    const applicableChallenges = CHALLENGE_TEMPLATES.filter(c => c.isApplicable(userProfile));
    
    // Avoid repeating the last challenge if there are other options
    const lastChallengeId = userProfile.currentChallenge?.id;
    let selectableChallenges = applicableChallenges;
    if (lastChallengeId && applicableChallenges.length > 1) {
        selectableChallenges = applicableChallenges.filter(c => c.id !== lastChallengeId);
    }
    
    if (selectableChallenges.length === 0) {
        // Fallback to all applicable challenges if filtering left none
        selectableChallenges = applicableChallenges;
    }

    if (selectableChallenges.length === 0) return null; // No challenges are suitable for this user
    
    // Select a random challenge from the applicable ones
    const selectedTemplate = selectableChallenges[Math.floor(Math.random() * selectableChallenges.length)];
    
    // Find up to 10 places that match this challenge to create variety
    const matchingPlaces = places.filter(p => selectedTemplate.isMatch(p, userProfile)).slice(0, 10);
    
    if (matchingPlaces.length === 0) return null; // Can't create a challenge without places
    
    // Shuffle and pick 1 or 2 places for the recommendation
    const recommendedPlaces = matchingPlaces.sort(() => 0.5 - Math.random()).slice(0, 2);
    
    return {
        id: selectedTemplate.id,
        title: selectedTemplate.title,
        description: selectedTemplate.description,
        generatedAt: new Date().toISOString(),
        relatedPlaceIds: recommendedPlaces.map(p => p.id),
    };
};