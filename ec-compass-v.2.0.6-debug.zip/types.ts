import firebase from 'firebase/compat/app';

declare global {
  // This tells TypeScript that a 'google' variable exists in the global scope.
  // It is of type 'any' to avoid having to define all the Google Maps types.
  namespace google {
    namespace maps {
      type Map = any;
      type Marker = any;
      const Animation: any;
      type Point = any;
    }
  }

  interface Window {
    google: any;
    googleMapsApiLoaded?: boolean;
  }
}

export type VibeType = 'Camera' | 'Gift' | 'Coffee' | 'Music' | 'Moon' | 'Heart' | 'ChevronRight' | 'MapPin' | 'Clock' | 'DollarSign' | 'Star' | 'Sparkles' | 'BookOpen' | 'User' | 'Users' | 'PartyPopper' | 'MicOff' | 'MessageCircle' | 'UserPlus' | 'Wifi' | 'Wand2' | 'Footprints' | 'Award' | 'GraduationCap' | 'Briefcase' | 'Compass' | 'Home' | 'Target' | 'MessagesSquare' | 'UtensilsCrossed' | 'Bookmark' | 'CalendarDays' | 'Sun' | 'Lightbulb' | 'Cloud' | 'Wind' | 'CloudRain';

export interface Image {
  url: string;
  thumb: string;
  author: string;
  source: string;
}

export interface Place {
  id: string;
  name: string;
  category: string;
  location: {
    address: string;
    neighborhood: string;
    walkFromEC: string;
    coordinates: {
      lat: number;
      lng: number;
    };
  };
  pricing: {
    range: string;
    average: string;
  };
  details: {
    description: string;
    hours: string;
    bestTime: string;
    whySpecial: string;
    funFacts: string[];
    localTip: string;
  };
  englishCorner: {
    conversationStarters: string[];
    usefulPhrases: string[];
    culturalContext: string;
  };
  tags: {
    vibeTags: string[];
    bestFor?: string[];
  };
  imageUrl?: string; // Main image for cards, derived from `images[0].thumb`
  images?: Image[]; // Carousel images
}

export interface Challenge {
  id: 'new_neighborhood' | 'small_talk' | 'study_spot' | 'local_taste';
  title: string;
  description: string;
  generatedAt: string; // ISO String date
  relatedPlaceIds: string[];
}

export interface UserProfile {
  englishLevel: 'confident' | 'getting-there' | 'starting' | null;
  userVibe: 'explorer' | 'socializer' | 'learner' | null;
  stayDuration: 'short' | 'medium' | 'long' | null;
  onboardingCompleted: boolean;
  currentChallenge?: Challenge;
  firstName?: string;
  country?: string;
  school?: string;
  class?: string;
}

export interface PublicUserProfile {
    uid: string;
    firstName: string;
    country: string;
    school: string;
    class?: string;
    photoURL: string;
}

export interface PlaceInterest {
    [userId: string]: true;
}

export interface PlaceInsights {
  englishComfort: number; // A score from 1 to 5
  socialLevel: 'Quiet' | 'Moderate' | 'Lively' | 'Very Social';
  bestFor: 'Solo' | 'Group' | 'Mixed';
}

export interface ContextualSuggestion {
    title: string;
    description: string;
    recommendedPlaceIds: string[];
}

export interface WalkTourStep {
    placeId: string;
    instruction: string;
}

export interface WalkTour {
    title: string;
    steps: WalkTourStep[];
}

export interface BucketListItem {
  status: 'want-to-go' | 'been-there';
  addedAt: string; // ISO string
  scheduledDate?: string | null; // ISO string (e.g., 'YYYY-MM-DD')
}

export interface Event {
  id: string;
  placeId: string;
  schoolId: string;
  createdBy: {
    uid: string;
    firstName: string;
    photoURL: string;
  };
  dateTime: string; // ISO string
  groupPrivacy: 'school' | 'class';
  maxParticipants: number;
  vibe: string;
  meetingPoint: string;
  details: string;
  createdAt: string; // ISO string
}

export interface EventAttendee {
  [userId: string]: {
    firstName: string;
    photoURL: string;
    status: 'going';
  }
}

export interface EventComment {
  id: string;
  text: string;
  createdAt: string; // ISO string
  createdBy: {
    uid: string;
    firstName: string;
    photoURL: string;
  };
}


export interface AppContextType {
  places: Place[];
  isLoading: boolean;
  isAuthLoading: boolean;
  error: string | null;
  user: User | null;
  isAdmin: boolean;
  userProfile: UserProfile | null;
  bucketList: { [placeId: string]: BucketListItem };
  events: Event[];
  getPlaceById: (id: string) => Place | undefined;
  addToBucketList: (placeId: string) => Promise<void>;
  removeFromBucketList: (placeId: string) => Promise<void>;
  updateBucketListItem: (placeId: string, data: Partial<BucketListItem>) => Promise<void>;
  signOut: () => Promise<void>;
  createEvent: (eventData: Omit<Event, 'id' | 'createdAt' | 'createdBy' | 'schoolId'>) => Promise<string | undefined>;
  rsvpToEvent: (eventId: string, status: 'going' | 'cant-go') => Promise<void>;
  addEventComment: (eventId: string, commentText: string) => Promise<void>;
}


export type User = firebase.User;

export type WeatherCondition = 'Sunny' | 'Cloudy' | 'Foggy' | 'Rainy';

export interface Weather {
    temp: number;
    condition: WeatherCondition;
    icon: 'Sun' | 'Cloud' | 'Wind' | 'CloudRain';
}