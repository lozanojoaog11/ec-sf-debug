
import React, { lazy, Suspense } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { AppProvider, useAppContext } from './context/AppContext.tsx';
import Header from './components/common/Header.tsx';
import { Skeleton } from './components/common/Skeleton.tsx';

// Lazy load pages for code splitting and better performance
const HomePage = lazy(() => import('./components/HomePage.tsx'));
const PlaceDetailPage = lazy(() => import('./components/PlaceDetailPage.tsx'));
const MapPage = lazy(() => import('./components/MapPage.tsx'));
const VibeListPage = lazy(() => import('./components/VibeListPage.tsx'));
const LoginPage = lazy(() => import('./components/LoginPage.tsx'));
const AddPlacePage = lazy(() => import('./components/AddPlacePage.tsx'));
const ProtectedRoute = lazy(() => import('./components/ProtectedRoute.tsx'));
const AdminRoute = lazy(() => import('./components/AdminRoute.tsx'));
const OnboardingPage = lazy(() => import('./components/OnboardingPage.tsx'));
const BucketListPage = lazy(() => import('./components/BucketListPage.tsx'));
const EventsPage = lazy(() => import('./components/EventsPage.tsx'));
const EventDetailPage = lazy(() => import('./components/EventDetailPage.tsx'));


const PageWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.4, ease: "circOut" }}
  >
    {children}
  </motion.div>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageWrapper><HomePage /></PageWrapper>} />
        <Route path="/place/:id" element={<PageWrapper><PlaceDetailPage /></PageWrapper>} />
        <Route path="/map" element={<PageWrapper><MapPage /></PageWrapper>} />
        <Route path="/vibe/:vibe" element={<PageWrapper><VibeListPage /></PageWrapper>} />
        <Route path="/login" element={<PageWrapper><LoginPage /></PageWrapper>} />
        <Route 
          path="/add-place" 
          element={
            <AdminRoute>
              <PageWrapper><AddPlacePage /></PageWrapper>
            </AdminRoute>
          } 
        />
        <Route 
          path="/bucket-list" 
          element={
            <ProtectedRoute>
              <PageWrapper><BucketListPage /></PageWrapper>
            </ProtectedRoute>
          } 
        />
         <Route 
          path="/events" 
          element={
            <ProtectedRoute>
              <PageWrapper><EventsPage /></PageWrapper>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/event/:eventId" 
          element={
            <ProtectedRoute>
              <PageWrapper><EventDetailPage /></PageWrapper>
            </ProtectedRoute>
          } 
        />
      </Routes>
    </AnimatePresence>
  );
};

const FullScreenLoader = () => (
    <div className="flex items-center justify-center min-h-screen bg-[#FDFCF9]">
        <div className="w-full max-w-sm p-8 space-y-6">
            <Skeleton className="h-12 w-3/4 mx-auto" />
            <Skeleton className="h-8 w-1/2 mx-auto" />
            <div className="pt-8 space-y-4">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
            </div>
        </div>
    </div>
);

const AppContent = () => {
    const { user, isAuthLoading, userProfile } = useAppContext();

    if (isAuthLoading || (user && !user.isAnonymous && userProfile === null)) {
        return <FullScreenLoader />;
    }
    
    // Use Suspense for OnboardingPage as well, in case it's the first page shown
    if (user && !user.isAnonymous && userProfile && !userProfile.onboardingCompleted) {
        return <Suspense fallback={<FullScreenLoader />}><OnboardingPage /></Suspense>;
    }

    return (
        <div className="max-w-lg lg:max-w-5xl mx-auto bg-[#FDFCF9] min-h-screen lg:shadow-2xl lg:shadow-slate-500/10 lg:my-10 lg:rounded-3xl lg:border lg:border-slate-200/50">
            <Header />
            <main className="p-4 sm:p-6 lg:p-10">
                <Suspense fallback={<FullScreenLoader />}>
                    <AnimatedRoutes />
                </Suspense>
            </main>
        </div>
    );
};


export default function App() {
  return (
    <AppProvider>
      <HashRouter>
        <AppContent />
      </HashRouter>
    </AppProvider>
  );
}